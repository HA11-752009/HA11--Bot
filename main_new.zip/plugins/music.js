// =============================================
// plugins/music.js — تنزيل صوت وفيديو مع صورة الغلاف (من yt-search)
// =============================================
const fs = require('fs');
const path = require('path');
const { execSync, spawn } = require('child_process');
const { logToApp } = require('../ws');
const { fetchMediaAsBuffer } = require('../utils');

let yts;
try {
    yts = require('yt-search');
} catch (e) {
    logToApp('⚠️ yt-search غير مثبت. قم بتثبيته: `npm install yt-search`');
}

function findFfmpeg() {
    try {
        execSync('ffmpeg -version', { stdio: 'ignore', shell: true });
        return 'ffmpeg';
    } catch {}
    return null;
}
const FFMPEG = findFfmpeg();

const TEMP_DIR = path.join(__dirname, '..', 'temp_media');
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

function deleteFile(filePath) {
    try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch {}
}

function findYtDlp() {
    const isWindows = process.platform === 'win32';
    const candidates = isWindows ? [
        path.join(process.env.USERPROFILE || '', 'AppData', 'Local', 'Programs', 'Python', 'Python311', 'Scripts', 'yt-dlp.exe'),
        path.join(process.env.USERPROFILE || '', 'AppData', 'Local', 'Programs', 'Python', 'Python312', 'Scripts', 'yt-dlp.exe'),
        'C:\\Python311\\Scripts\\yt-dlp.exe',
        'C:\\Python312\\Scripts\\yt-dlp.exe',
        path.join(__dirname, '..', 'bin', 'yt-dlp.exe'),
        'yt-dlp.exe'
    ] : [
        '/usr/local/bin/yt-dlp',
        '/usr/bin/yt-dlp',
        path.join(process.env.HOME || '', '.local', 'bin', 'yt-dlp'),
        path.join(__dirname, '..', 'bin', 'yt-dlp'),
        'yt-dlp'
    ];

    for (const candidate of candidates) {
        try {
            if (fs.existsSync(candidate)) {
                execSync(`"${candidate}" --version`, { stdio: 'ignore', shell: true });
                logToApp(`✅ تم العثور على yt-dlp في: ${candidate}`);
                return candidate;
            }
        } catch {}
    }

    try {
        const whichCmd = isWindows ? 'where yt-dlp' : 'which yt-dlp';
        const result = execSync(whichCmd, { encoding: 'utf8', shell: true }).trim();
        if (result) {
            logToApp(`✅ تم العثور على yt-dlp عبر ${whichCmd}: ${result.split('\n')[0]}`);
            return result.split('\n')[0];
        }
    } catch {}

    logToApp('❌ لم يتم العثور على yt-dlp. يرجى تثبيته من https://github.com/yt-dlp/yt-dlp');
    return null;
}

const YT_DLP = findYtDlp();

/**
 * الحصول على رابط الفيديو ورابط الصورة المصغرة.
 */
async function getVideoInfo(query) {
    if (query.startsWith('http')) {
        try {
            const thumbUrl = execSync(`"${YT_DLP}" --get-thumbnail "${query}"`, { encoding: 'utf8', shell: true }).trim();
            return { url: query, thumbnail: thumbUrl || null };
        } catch {
            return { url: query, thumbnail: null };
        }
    }
    if (!yts) throw new Error('yt-search غير مثبت. تأكد من تثبيته بـ `npm install yt-search`.');
    const results = await yts(query);
    const videos = results.videos;
    if (!videos || videos.length === 0) throw new Error('لم يتم العثور على نتائج.');
    const video = videos[0];
    logToApp(`✅ بحث: ${video.title} (${video.url})`);
    return { url: video.url, thumbnail: video.thumbnail || null, title: video.title };
}

/**
 * تنزيل الميديا. تُرجع filePath, thumbnailUrl, title.
 */
async function downloadMedia(query, type, quality = 'best') {
    if (!YT_DLP) throw new Error('yt-dlp غير مثبت.');
    if (type === 'audio' && !FFMPEG) throw new Error('FFmpeg غير مثبت.');

    const { url: videoUrl, thumbnail: thumbnailUrl, title: infoTitle } = await getVideoInfo(query);
    const stamp = Date.now();
    const ext = type === 'audio' ? 'mp3' : 'mp4';
    const filePath = path.join(TEMP_DIR, `${type}_${stamp}.${ext}`);

    let formatArg;
    if (type === 'audio') {
        formatArg = 'bestaudio';
    } else {
        if (quality === '720p') formatArg = 'best[height<=720][ext=mp4]';
        else if (quality === '480p') formatArg = 'best[height<=480][ext=mp4]';
        else if (quality === '360p') formatArg = 'best[height<=360][ext=mp4]';
        else formatArg = 'best[ext=mp4]';
    }

    const args = type === 'audio'
        ? ['-f', formatArg, '--extract-audio', '--audio-format', 'mp3', '-o', filePath]
        : ['-f', formatArg, '-o', filePath];

    logToApp(`📥 تنزيل (${type} / ${quality}): ${videoUrl}`);

    return new Promise((resolve, reject) => {
        const proc = spawn(YT_DLP, [...args, videoUrl], { shell: true });
        let stderr = '';
        proc.stderr.on('data', (data) => { stderr += data.toString(); });

        proc.on('close', (code) => {
            if (code !== 0) {
                reject(new Error(`yt-dlp exited with code ${code}: ${stderr.slice(-200)}`));
                return;
            }
            const title = infoTitle || 'بدون عنوان';
            logToApp(`✅ تم التنزيل: ${title}`);
            resolve({ filePath, thumbnailUrl, title });
        });

        proc.on('error', (err) => reject(new Error(`فشل التنزيل: ${err.message}`)));
    });
}

// =============== معالجات الأوامر ===============
async function audioHandler({ sock, from, args }) {
    const query = args.join(' ').trim();
    if (!query) {
        await sock.sendMessage(from, { text: '🎵 *استخدم:* !موسيقى <اسم الأغنية أو رابط>' });
        return;
    }
    try {
        await sock.sendMessage(from, { text: '🔍 جاري البحث عن الأغنية...' });
        const { filePath, thumbnailUrl, title } = await downloadMedia(query, 'audio');

        // 1. إرسال صورة الغلاف أولاً إذا وُجد رابط الصورة
        if (thumbnailUrl) {
            try {
                const imageBuffer = await fetchMediaAsBuffer(thumbnailUrl);
                await sock.sendMessage(from, {
                    image: imageBuffer,
                    caption: `🎵 ${title}`
                });
            } catch (err) {
                logToApp(`⚠️ فشل تحميل/إرسال صورة الغلاف: ${err.message}`);
            }
        }

        // 2. إرسال الصوت
        await sock.sendMessage(from, {
            audio: { url: filePath },
            mimetype: 'audio/mpeg',
            fileName: `${title}.mp3`
        });

        logToApp(`✅ تم إرسال الصوت: ${title}`);
        setTimeout(() => deleteFile(filePath), 60000);
    } catch (err) {
        logToApp(`❌ فشل تنزيل الصوت: ${err.message}`);
        await sock.sendMessage(from, { text: `❌ فشل تنزيل الصوت: ${err.message}` });
    }
}

async function videoBestHandler({ sock, from, args }) {
    await handleVideo(sock, from, args, 'best');
}

async function video720Handler({ sock, from, args }) {
    await handleVideo(sock, from, args, '720p');
}

async function video480Handler({ sock, from, args }) {
    await handleVideo(sock, from, args, '480p');
}

async function video360Handler({ sock, from, args }) {
    await handleVideo(sock, from, args, '360p');
}

async function handleVideo(sock, from, args, quality) {
    const query = args.join(' ').trim();
    if (!query) {
        await sock.sendMessage(from, { text: '🎬 *استخدم:* !فيديو <اسم أو رابط>' });
        return;
    }
    try {
        await sock.sendMessage(from, { text: '🔍 جاري البحث عن الفيديو...' });
        const { filePath, title } = await downloadMedia(query, 'video', quality);
        await sock.sendMessage(from, {
            video: { url: filePath },
            caption: `🎬 ${title} [${quality}]`
        });
        logToApp(`✅ تم إرسال الفيديو: ${title}`);
        setTimeout(() => deleteFile(filePath), 60000);
    } catch (err) {
        logToApp(`❌ فشل تنزيل الفيديو: ${err.message}`);
        await sock.sendMessage(from, { text: `❌ فشل تنزيل الفيديو: ${err.message}` });
    }
}

module.exports = [
    { trigger: 'موسيقى',    description: 'تنزيل صوت mp3 مع صورة الغلاف', handler: audioHandler },
    { trigger: 'فيديو',     description: 'تنزيل فيديو (أفضل جودة)', handler: videoBestHandler },
    { trigger: 'فيديو720',  description: 'تنزيل فيديو 720p', handler: video720Handler },
    { trigger: 'فيديو480',  description: 'تنزيل فيديو 480p', handler: video480Handler },
    { trigger: 'فيديو360',  description: 'تنزيل فيديو 360p', handler: video360Handler },
];