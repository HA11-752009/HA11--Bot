// routes/groups.js
const express = require('express');
const router = express.Router();
const stateModule = require('../state');
const { logToApp } = require('../ws');

function getSock(phone) {
    if (phone) {
        const session = stateModule.getSession(phone);
        if (session?.isConnected) return session.sock;
        return null;
    }
    const primary = stateModule.getPrimarySession();
    return primary?.sock || null;
}

// جلب جميع المجموعات (يدعم معامل phone)
router.get('/', async (req, res) => {
    const phone = req.query.phone;
    const sock = getSock(phone);
    if (!sock) {
        return res.json({ groups: [], total: 0, error: 'البوت غير متصل' });
    }
    try {
        let groupsData = await sock.groupFetchAllParticipating();
        let groupsList = [];
        
        // --- الإصلاح الجذري لمشكلة "مشرف" ---
        // JID البوت الكامل كما يراه sock (مثل 201003128866:2@s.whatsapp.net)
        const fullBotJid = sock.user?.id;
        // JID البوت بدون الجزء ":2" لمطابقته مع قائمة المشاركين (مثل 201003128866@s.whatsapp.net)
        const normalizedBotJid = fullBotJid ? fullBotJid.replace(/:\d+/, '') : null;
        
        if (groupsData && Object.keys(groupsData).length > 0) {
            groupsList = Object.values(groupsData).map(g => {
                // حساب isAdmin باستخدام JID المطابق
                const isAdmin = g.participants?.some(p => 
                    p.id === normalizedBotJid && (p.admin === 'admin' || p.admin === 'superadmin')
                ) || false;
                
                return {
                    id: g.id,
                    name: g.subject || g.name || 'بدون اسم',
                    description: g.desc || '',
                    memberCount: g.participants?.length || 0,
                    isAdmin: isAdmin,
                    settings: {
                        // في Baileys: g.announce = true يعني الإرسال مقيد (للمشرفين فقط)
                        announcement: g.announce || false,
                        // في Baileys: g.restrict = true يعني الإضافة مقيدة (للمشرفين فقط)
                        restrict: g.restrict || false
                    }
                };
            });
        } else {
            try {
                const chats = await sock.store?.chats?.all() || [];
                groupsList = chats
                    .filter(c => c.id?.endsWith('@g.us'))
                    .map(c => ({
                        id: c.id,
                        name: c.name || 'بدون اسم',
                        description: '',
                        memberCount: 0,
                        isAdmin: false,
                        settings: { announcement: false, restrict: false }
                    }));
            } catch (e) {
                groupsList = [];
            }
        }
        res.json({ groups: groupsList, total: groupsList.length });
    } catch (err) {
        console.error('Error fetching groups:', err);
        res.status(500).json({ error: err.message });
    }
});

// جلب أعضاء مجموعة محددة
router.get('/:groupId/participants', async (req, res) => {
    const phone = req.query.phone;
    const sock = getSock(phone);
    if (!sock) return res.status(401).json({ error: 'غير متصل' });
    try {
        const meta = await sock.groupMetadata(req.params.groupId);
        const participants = meta.participants.map(p => ({
            id: p.id,
            name: p.notify || p.pushName || p.id.split('@')[0],
            isAdmin: p.admin === 'admin' || p.admin === 'superadmin'
        }));
        res.json({ participants, total: participants.length });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// إضافة عضو
router.post('/:groupId/add', async (req, res) => {
    const { phone, sessionPhone } = req.body;
    if (!phone) {
        return res.status(400).json({ success: false, message: 'رقم العضو مطلوب' });
    }
    const sock = getSock(sessionPhone);
    if (!sock) {
        return res.status(401).json({ success: false, message: 'الجلسة غير متصلة' });
    }
    let memberJid = phone.includes('@') ? phone : `${phone.replace(/\D/g, '')}@s.whatsapp.net`;
    try {
        await sock.groupParticipantsUpdate(req.params.groupId, [memberJid], 'add');
        res.json({ success: true });
    } catch (err) {
        logToApp(`❌ فشل إضافة عضو: ${err.message}`);
        res.status(500).json({ success: false, message: err.message });
    }
});

// إزالة عضو
router.post('/:groupId/remove', async (req, res) => {
    const { phone, sessionPhone } = req.body;
    const sock = getSock(sessionPhone);
    if (!sock) return res.status(401).json({ success: false });
    let memberJid = phone.includes('@') ? phone : `${phone.replace(/\D/g, '')}@s.whatsapp.net`;
    try {
        await sock.groupParticipantsUpdate(req.params.groupId, [memberJid], 'remove');
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// ترقية مشرف
router.post('/:groupId/promote', async (req, res) => {
    const { phone, sessionPhone } = req.body;
    const sock = getSock(sessionPhone);
    if (!sock) return res.status(401).json({ success: false });
    let memberJid = phone.includes('@') ? phone : `${phone.replace(/\D/g, '')}@s.whatsapp.net`;
    try {
        await sock.groupParticipantsUpdate(req.params.groupId, [memberJid], 'promote');
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// خفض مشرف
router.post('/:groupId/demote', async (req, res) => {
    const { phone, sessionPhone } = req.body;
    const sock = getSock(sessionPhone);
    if (!sock) return res.status(401).json({ success: false });
    let memberJid = phone.includes('@') ? phone : `${phone.replace(/\D/g, '')}@s.whatsapp.net`;
    try {
        await sock.groupParticipantsUpdate(req.params.groupId, [memberJid], 'demote');
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// قبول طلب انضمام
router.post('/:groupId/accept-request', async (req, res) => {
    const { jid, sessionPhone } = req.body;
    const sock = getSock(sessionPhone);
    if (!sock) return res.status(401).json({ success: false });
    try {
        await sock.groupRequestParticipantsUpdate(req.params.groupId, [jid], 'approve');
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// رفض طلب انضمام
router.post('/:groupId/reject-request', async (req, res) => {
    const { jid, sessionPhone } = req.body;
    const sock = getSock(sessionPhone);
    if (!sock) return res.status(401).json({ success: false });
    try {
        await sock.groupRequestParticipantsUpdate(req.params.groupId, [jid], 'reject');
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

// جلب طلبات الانضمام
router.get('/:groupId/join-requests', async (req, res) => {
    const sessionPhone = req.query.sessionPhone;
    const sock = getSock(sessionPhone);
    if (!sock) return res.status(401).json({ error: 'غير متصل' });
    try {
        const requests = await sock.groupRequestParticipantsList(req.params.groupId);
        const list = (requests || []).map(r => ({
            id: r.jid,
            jid: r.jid,
            name: r.notify || r.jid.split('@')[0],
            requestedAt: r.requestTime ? new Date(r.requestTime * 1000).toISOString() : new Date().toISOString()
        }));
        res.json({ requests: list, total: list.length });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;