// plugins/warnings.js — نظام تحذيرات وطرد تلقائي
const fs = require('fs');
const path = require('path');
const { logToApp } = require('../ws');

const DATA_FILE = path.join(__dirname, '..', 'warnings_data.json');

function loadWarnings() {
    try {
        if (fs.existsSync(DATA_FILE))
            return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    } catch (e) {}
    return {};
}

function saveWarnings(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function getPhone(jid) {
    return jid ? jid.split('@')[0] : '';
}

async function getMemberName(sock, groupId, jid) {
    try {
        const meta = await sock.groupMetadata(groupId);
        const member = meta.participants.find(p => p.id === jid);
        return member?.notify || member?.pushName || getPhone(jid);
    } catch {
        return getPhone(jid);
    }
}

async function addWarning(sock, groupId, userJid, reason, adminJid = null) {
    const warnings = loadWarnings();
    if (!warnings[groupId]) warnings[groupId] = {};
    const phone = getPhone(userJid);
    if (!warnings[groupId][phone]) warnings[groupId][phone] = { count: 0, reasons: [] };
    warnings[groupId][phone].count++;
    warnings[groupId][phone].reasons.push({
        reason,
        date: new Date().toISOString(),
        by: adminJid ? getPhone(adminJid) : 'system'
    });
    saveWarnings(warnings);
    const newCount = warnings[groupId][phone].count;
    const userName = await getMemberName(sock, groupId, userJid);
    await sock.sendMessage(groupId, {
        text: `⚠️ *تحذير ${newCount}/3* للعضو ${userName}\nالسبب: ${reason}\nعند بلوغ 3 تحذيرات سيتم الطرد.`,
        mentions: [userJid]
    });
    if (newCount >= 3) {
        try {
            await sock.groupParticipantsUpdate(groupId, [userJid], 'remove');
            await sock.sendMessage(groupId, {
                text: `🚫 تم طرد ${userName} تلقائياً لبلوغه 3 تحذيرات.`,
                mentions: [userJid]
            });
            delete warnings[groupId][phone];
            saveWarnings(warnings);
        } catch (err) {
            logToApp(`❌ فشل الطرد التلقائي: ${err.message}`);
        }
    }
    return newCount;
}

function extractTarget(msg, args) {
    const ctxInfo = msg.message?.extendedTextMessage?.contextInfo;
    if (ctxInfo?.participant) return ctxInfo.participant;
    if (ctxInfo?.mentionedJid?.length > 0) return ctxInfo.mentionedJid[0];
    if (args.length > 0) {
        const num = args[0].replace(/\D/g, '');
        if (num.length >= 10) return `${num}@s.whatsapp.net`;
    }
    return null;
}

// الأوامر (مصفوفة)
const commands = [
    {
        trigger: 'تحذير',
        description: 'إعطاء تحذير لعضو (للمشرفين) ⚠️',
        groupOnly: true,
        adminOnly: true,
        handler: async ({ sock, from, msg, args, senderJid }) => {
            const targetJid = extractTarget(msg, args);
            if (!targetJid) {
                await sock.sendMessage(from, { text: '⚠️ قم بالرد على رسالة العضو أو اذكر اسمه (@username) أو اكتب رقمه.' });
                return;
            }
            const reason = args.slice(1).join(' ') || 'مخالفة قوانين المجموعة';
            await addWarning(sock, from, targetJid, reason, senderJid);
        }
    },
    {
        trigger: 'تحذيرات',
        description: 'عرض عدد تحذيرات عضو 📊',
        groupOnly: true,
        handler: async ({ sock, from, msg, args, senderJid }) => {
            let targetJid = extractTarget(msg, args);
            if (!targetJid) targetJid = senderJid;
            const warnings = loadWarnings();
            const phone = getPhone(targetJid);
            const data = warnings[from]?.[phone] || { count: 0, reasons: [] };
            const userName = await getMemberName(sock, from, targetJid);
            let text = `📋 *تحذيرات العضو ${userName}:* ${data.count}/3\n`;
            if (data.reasons.length > 0) {
                text += `\n*الأسباب:*\n`;
                data.reasons.forEach((r, i) => {
                    text += `${i+1}. ${r.reason} (${new Date(r.date).toLocaleString()}) بواسطة ${r.by}\n`;
                });
            } else {
                text += `\n✨ لا توجد تحذيرات.`;
            }
            await sock.sendMessage(from, { text, mentions: [targetJid] });
        }
    },
    {
        trigger: 'مسح',
        description: 'مسح تحذيرات عضو (للمشرفين) ✅',
        groupOnly: true,
        adminOnly: true,
        handler: async ({ sock, from, msg, args, senderJid }) => {
            const targetJid = extractTarget(msg, args);
            if (!targetJid) {
                await sock.sendMessage(from, { text: '⚠️ قم بالرد على رسالة العضو أو اذكر اسمه.' });
                return;
            }
            const warnings = loadWarnings();
            const phone = getPhone(targetJid);
            if (warnings[from] && warnings[from][phone]) {
                delete warnings[from][phone];
                saveWarnings(warnings);
                const userName = await getMemberName(sock, from, targetJid);
                await sock.sendMessage(from, {
                    text: `✅ تم مسح جميع تحذيرات ${userName} بواسطة @${getPhone(senderJid)}.`,
                    mentions: [targetJid, senderJid]
                });
            } else {
                await sock.sendMessage(from, { text: `ℹ️ العضو ليس لديه تحذيرات.`, mentions: [targetJid] });
            }
        }
    },
    {
        trigger: 'طرد',
        description: 'طرد عضو من المجموعة 🚫',
        groupOnly: true,
        adminOnly: true,
        handler: async ({ sock, from, msg, args }) => {
            const targetJid = extractTarget(msg, args);
            if (!targetJid) {
                await sock.sendMessage(from, { text: '⚠️ قم بالرد على رسالة العضو أو اذكر اسمه.' });
                return;
            }
            try {
                await sock.groupParticipantsUpdate(from, [targetJid], 'remove');
                await sock.sendMessage(from, {
                    text: `🚫 تم طرد @${getPhone(targetJid)} من المجموعة.`,
                    mentions: [targetJid]
                });
                const warnings = loadWarnings();
                const phone = getPhone(targetJid);
                if (warnings[from] && warnings[from][phone]) {
                    delete warnings[from][phone];
                    saveWarnings(warnings);
                }
            } catch (err) {
                await sock.sendMessage(from, { text: `❌ فشل الطرد: ${err.message}` });
            }
        }
    },
    {
        trigger: 'قوانين',
        description: 'عرض قوانين المجموعة 📜',
        groupOnly: true,
        handler: async ({ sock, from, args, senderJid, settings }) => {
            const rulesFile = path.join(__dirname, '..', 'group_rules.json');
            let rules = {};
            try { if (fs.existsSync(rulesFile)) rules = JSON.parse(fs.readFileSync(rulesFile, 'utf8')); } catch {}
            const isAdmin = senderJid ? await (async () => {
                try { const meta = await sock.groupMetadata(from); return meta.participants.some(p => p.id === senderJid && (p.admin === 'admin' || p.admin === 'superadmin')); } catch { return false; }
            })() : false;
            if (args.length > 0 && isAdmin) {
                const newRules = args.join(' ');
                rules[from] = newRules;
                fs.writeFileSync(rulesFile, JSON.stringify(rules, null, 2));
                await sock.sendMessage(from, { text: `✅ تم تحديث قوانين المجموعة.\n\n${newRules}` });
            } else {
                const groupRules = rules[from] || 'لا توجد قوانين محددة لهذه المجموعة. يمكن للمشرفين تعيينها بـ `!قوانين النص...`.';
                await sock.sendMessage(from, { text: `📜 *قوانين المجموعة:*\n\n${groupRules}` });
            }
        }
    }
];

// تصدير الأوامر والدالة addWarning
module.exports = commands;
module.exports.addWarning = addWarning;

logToApp('⚠️ Warnings plugin loaded: طرد, تحذير, تحذيرات, مسح, قوانين');