// =============================================
// plugins/games.js — الألعاب التفاعلية
// =============================================

// ── ذاكرة الألعاب الجارية ─────────────────
const activeGames = new Map(); // chatId → gameState

// ── أسئلة التريفيا ───────────────────────
const triviaQuestions = [
    { q: '🌍 ما عاصمة فرنسا؟', a: 'باريس', options: ['لندن', 'باريس', 'برلين', 'مدريد'] },
    { q: '🔢 كم عدد أيام السنة الكبيسة؟', a: '366', options: ['365', '366', '367', '364'] },
    { q: '🌊 ما أكبر محيط في العالم؟', a: 'المحيط الهادئ', options: ['المحيط الأطلسي', 'المحيط الهندي', 'المحيط الهادئ', 'البحر المتوسط'] },
    { q: '⚽ كم مرة فازت البرازيل بكأس العالم؟', a: '5', options: ['3', '4', '5', '6'] },
    { q: '🦈 ما أكبر سمكة في العالم؟', a: 'القرش الحوتي', options: ['التونة', 'القرش الأبيض', 'القرش الحوتي', 'البلطي'] },
    { q: '🌙 كم يبعد القمر عن الأرض تقريباً؟', a: '384,400 كم', options: ['100,000 كم', '250,000 كم', '384,400 كم', '500,000 كم'] },
    { q: '💻 من اخترع الإنترنت؟', a: 'تيم بيرنرز لي', options: ['بيل غيتس', 'ستيف جوبز', 'تيم بيرنرز لي', 'مارك زوكربيرج'] },
    { q: '🐘 ما أكبر حيوان بري في العالم؟', a: 'الفيل الأفريقي', options: ['الزرافة', 'وحيد القرن', 'الفيل الأفريقي', 'أفراس النهر'] },
    { q: '⚗️ ما الرمز الكيميائي للذهب؟', a: 'Au', options: ['Go', 'Gd', 'Au', 'Ag'] },
    { q: '📐 كم زاوية المثلث متساوي الأضلاع؟', a: '60 درجة', options: ['45 درجة', '60 درجة', '90 درجة', '120 درجة'] },
    { q: '🌺 ما اسم أكبر زهرة في العالم؟', a: 'رافليسيا', options: ['السوسنة', 'عباد الشمس', 'رافليسيا', 'الأوركيد'] },
    { q: '🎸 من غنى Bohemian Rhapsody؟', a: 'كوين', options: ['بيتلز', 'رولينج ستونز', 'كوين', 'ليد زيبلين'] },
    { q: '🚀 من أول إنسان وطأت قدمه القمر؟', a: 'نيل أرمسترونج', options: ['باز ألدرين', 'نيل أرمسترونج', 'يوري غاغارين', 'جون غلين'] },
    { q: '🍕 ما أصل البيتزا؟', a: 'إيطاليا', options: ['أمريكا', 'إيطاليا', 'فرنسا', 'اليونان'] },
];

function getRandom(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function shuffle(arr) { return [...arr].sort(() => Math.random() - 0.5); }

module.exports = [
    // ── 1. تخمين الرقم ──────────────────────
    {
        trigger: 'خمن',
        description: 'لعبة تخمين الرقم 🎯',
        handler: async ({ sock, from, args }) => {
            // لو أرسل رقم للتخمين
            if (activeGames.has(from) && activeGames.get(from).type === 'number') {
                const game = activeGames.get(from);
                const guess = parseInt(args[0]);
                if (isNaN(guess)) {
                    await sock.sendMessage(from, { text: '❌ أرسل رقم صحيح!' });
                    return;
                }
                game.attempts++;
                if (guess === game.number) {
                    activeGames.delete(from);
                    await sock.sendMessage(from, {
                        text: `🎉 *صح!* الرقم كان *${game.number}*\n🏆 عدد المحاولات: ${game.attempts}`
                    });
                } else {
                    const hint = guess < game.number ? '⬆️ أكبر' : '⬇️ أصغر';
                    const remaining = game.maxAttempts - game.attempts;
                    if (remaining <= 0) {
                        activeGames.delete(from);
                        await sock.sendMessage(from, {
                            text: `😢 *خسرت!* الرقم كان *${game.number}*\nاكتب !خمن لتلعب مرة ثانية`
                        });
                    } else {
                        await sock.sendMessage(from, {
                            text: `❌ غلط! ${hint}\n💡 متبقي ${remaining} محاولة من ${game.maxAttempts}`
                        });
                    }
                }
                return;
            }

            // بدء لعبة جديدة
            const max = parseInt(args[0]) || 100;
            const num = Math.floor(Math.random() * max) + 1;
            activeGames.set(from, { type: 'number', number: num, attempts: 0, maxAttempts: 7, max });
            await sock.sendMessage(from, {
                text: [
                    `🎯 *لعبة تخمين الرقم!*`,
                    `━━━━━━━━━━━━━━`,
                    `فكرت في رقم من 1 إلى ${max}`,
                    `عندك *7 محاولات* لتخمينه!`,
                    ``,
                    `أرسل: \`!خمن [رقم]\``,
                    `مثال: \`!خمن 50\``,
                ].join('\n')
            });
        }
    },
    {
        trigger: 'توقف',
        description: 'إيقاف اللعبة الحالية',
        handler: async ({ sock, from }) => {
            if (!activeGames.has(from)) {
                await sock.sendMessage(from, { text: '⚠️ مفيش لعبة جارية!' });
                return;
            }
            const game = activeGames.get(from);
            const answer = game.number || game.word || game.answer || '؟';
            activeGames.delete(from);
            await sock.sendMessage(from, { text: `⛔ اللعبة وقفت!\nكانت الإجابة: *${answer}*` });
        }
    },

    // ── 2. التريفيا ──────────────────────────
    {
        trigger: 'تريفيا',
        description: 'سؤال معلومات عامة 🧠',
        handler: async ({ sock, from, args }) => {
            // لو بيجاوب
            if (activeGames.has(from) && activeGames.get(from).type === 'trivia') {
                const game    = activeGames.get(from);
                const answer  = args.join(' ').trim();
                const correct = game.answer;
                activeGames.delete(from);

                if (answer.toLowerCase().includes(correct.toLowerCase()) ||
                    correct.toLowerCase().includes(answer.toLowerCase())) {
                    await sock.sendMessage(from, {
                        text: `✅ *صح!* 🎉\nالجواب: *${correct}*`
                    });
                } else {
                    await sock.sendMessage(from, {
                        text: `❌ *غلط!*\nجوابك: ${answer}\nالإجابة الصحيحة: *${correct}*`
                    });
                }
                return;
            }

            // سؤال جديد
            const question = getRandom(triviaQuestions);
            const opts     = shuffle(question.options);
            activeGames.set(from, { type: 'trivia', answer: question.a, startTime: Date.now() });

            await sock.sendMessage(from, {
                text: [
                    `🧠 *سؤال التريفيا:*`,
                    `━━━━━━━━━━━━━━`,
                    question.q,
                    ``,
                    opts.map((o, i) => `${['1️⃣','2️⃣','3️⃣','4️⃣'][i]} ${o}`).join('\n'),
                    ``,
                    `أرسل: \`!تريفيا [إجابتك]\``,
                    `مثال: \`!تريفيا باريس\``,
                ].join('\n')
            });

            // إيقاف بعد 60 ثانية
            setTimeout(() => {
                if (activeGames.has(from) && activeGames.get(from).type === 'trivia') {
                    activeGames.delete(from);
                    sock.sendMessage(from, { text: `⏰ انتهى الوقت!\nالإجابة كانت: *${question.a}*` }).catch(() => {});
                }
            }, 60000);
        }
    },

    // ── 3. لعبة الكلمة المقلوبة ──────────────
    {
        trigger: 'مقلوب',
        description: 'احزر الكلمة المقلوبة 🔄',
        handler: async ({ sock, from, args }) => {
            const wordList = [
                'مصر', 'القاهرة', 'العرب', 'الإسلام', 'النيل', 'البحر',
                'الشمس', 'القمر', 'النجوم', 'الأرض', 'السماء', 'الجبل',
                'البرتقال', 'الفراولة', 'التفاح', 'الموز', 'المانجو',
                'الكمبيوتر', 'الهاتف', 'الإنترنت', 'الذكاء',
            ];

            // إجابة
            if (activeGames.has(from) && activeGames.get(from).type === 'word') {
                const game   = activeGames.get(from);
                const answer = args.join(' ').trim();
                if (answer === game.word) {
                    activeGames.delete(from);
                    await sock.sendMessage(from, { text: `✅ *صح!* 🎉\nالكلمة كانت: *${game.word}*` });
                } else {
                    await sock.sendMessage(from, { text: `❌ غلط! حاول تاني\nتلميح: الكلمة ${game.word.length} حروف` });
                }
                return;
            }

            // كلمة جديدة
            const word     = getRandom(wordList);
            const reversed = word.split('').reverse().join('');
            activeGames.set(from, { type: 'word', word, startTime: Date.now() });

            await sock.sendMessage(from, {
                text: [
                    `🔄 *الكلمة المقلوبة:*`,
                    `━━━━━━━━━━━━━━`,
                    `\`${reversed}\``,
                    ``,
                    `احزر الكلمة الأصلية!`,
                    `أرسل: \`!مقلوب [كلمتك]\``,
                ].join('\n')
            });

            // إيقاف بعد 45 ثانية
            setTimeout(() => {
                if (activeGames.has(from) && activeGames.get(from).type === 'word') {
                    activeGames.delete(from);
                    sock.sendMessage(from, { text: `⏰ انتهى الوقت!\nالكلمة كانت: *${word}*` }).catch(() => {});
                }
            }, 45000);
        }
    },

    // ── 4. من أنا؟ ───────────────────────────
    {
        trigger: 'شخصية',
        description: 'لعبة من أنا؟ 🎭',
        handler: async ({ sock, from, args }) => {
            const celebrities = [
                { name: 'محمد صلاح', hints: ['لاعب كرة قدم', 'مصري', 'يلعب في ليفربول', 'الملك المصري'] },
                { name: 'ستيف جوبز', hints: ['مؤسس شركة كبيرة', 'أمريكي', 'توفي 2011', 'أسس Apple'] },
                { name: 'عمر شريف', hints: ['ممثل مصري', 'عالمي', 'لعب دور دكتور جيفاجو', 'ماتش الشمس'] },
                { name: 'أم كلثوم', hints: ['مغنية', 'مصرية', 'كوكب الشرق', 'جمهورها من كل العالم'] },
            ];

            if (activeGames.has(from) && activeGames.get(from).type === 'celebrity') {
                const game   = activeGames.get(from);
                const answer = args.join(' ').trim();
                if (answer.includes(game.name) || game.name.includes(answer)) {
                    activeGames.delete(from);
                    await sock.sendMessage(from, { text: `✅ *صح!* 🎉\nأنا: *${game.name}*` });
                } else {
                    game.hintIdx = (game.hintIdx || 0) + 1;
                    if (game.hintIdx >= game.hints.length) {
                        activeGames.delete(from);
                        await sock.sendMessage(from, { text: `❌ خسرت!\nكنت: *${game.name}*` });
                    } else {
                        await sock.sendMessage(from, {
                            text: `❌ غلط!\n💡 تلميح ${game.hintIdx + 1}: ${game.hints[game.hintIdx]}`
                        });
                    }
                }
                return;
            }

            const celeb = getRandom(celebrities);
            activeGames.set(from, { type: 'celebrity', name: celeb.name, hints: celeb.hints, hintIdx: 0 });
            await sock.sendMessage(from, {
                text: [
                    `🎭 *لعبة من أنا؟*`,
                    `━━━━━━━━━━━━━━`,
                    `💡 تلميح 1: ${celeb.hints[0]}`,
                    ``,
                    `احزر من أنا! أرسل: \`!شخصية [اسمك]\``,
                    `(عند الغلط هياخدك تلميح جديد)`,
                ].join('\n')
            });
        }
    },

    // ── 5. حساب سريع ─────────────────────────
    {
        trigger: 'احسب',
        description: 'مسألة حساب سريعة ➕',
        handler: async ({ sock, from, args }) => {
            if (activeGames.has(from) && activeGames.get(from).type === 'math') {
                const game   = activeGames.get(from);
                const answer = parseFloat(args[0]);
                activeGames.delete(from);
                if (Math.abs(answer - game.answer) < 0.01) {
                    const ms = Date.now() - game.startTime;
                    await sock.sendMessage(from, { text: `✅ *صح!* 🎉\nحليتها في ${(ms/1000).toFixed(1)} ثانية!` });
                } else {
                    await sock.sendMessage(from, { text: `❌ غلط!\nإجابتك: ${answer}\nالصح: *${game.answer}*` });
                }
                return;
            }

            const ops = ['+', '-', '*'];
            const op  = getRandom(ops);
            const a   = Math.floor(Math.random() * 50) + 1;
            const b   = Math.floor(Math.random() * 20) + 1;
            let answer;
            if (op === '+') answer = a + b;
            else if (op === '-') answer = a - b;
            else answer = a * b;

            activeGames.set(from, { type: 'math', answer, startTime: Date.now() });
            await sock.sendMessage(from, {
                text: [
                    `➕ *مسألة حساب سريعة:*`,
                    `━━━━━━━━━━━━━━`,
                    `*${a} ${op} ${b} = ?*`,
                    ``,
                    `أرسل: \`!احسب [الإجابة]\``,
                ].join('\n')
            });
        }
    },
];
