// routes/broadcast.js
const express = require('express');
const router = express.Router();
const stateModule = require('../state');
const { formatPhone } = require('../utils');
const { logToApp } = require('../ws');

/**
 * دالة مساعدة لجلب جميع الشاتات (فردية + مجموعات)
 */
async function getAllChats(sock) {
    let allChats = [];
    
    try {
        if (sock.store && sock.store.chats) {
            const chatsMap = sock.store.chats.chats;
            if (chatsMap instanceof Map) {
                allChats = Array.from(chatsMap.values());
            } else if (Array.isArray(chatsMap)) {
                allChats = chatsMap;
            } else if (typeof sock.store.chats.all === 'function') {
                allChats = sock.store.chats.all();
            }
        }
        else if (typeof sock.getChats === 'function') {
            allChats = await sock.getChats();
        }
        else if (sock.store && sock.store.messages) {
            const uniqueJids = new Set();
            for (const msg of sock.store.messages.values()) {
                if (msg.key && msg.key.remoteJid) {
                    uniqueJids.add(msg.key.remoteJid);
                }
            }
            allChats = Array.from(uniqueJids).map(jid => ({ id: jid, name: jid.split('@')[0] }));
        }
    } catch (e) {
        console.error('[Broadcast] Error fetching chats:', e);
    }
    
    return allChats;
}

/**
 * دالة مساعدة لجلب جميع المجموعات فقط
 */
async function getAllGroups(sock) {
    let groups = [];
    try {
        const groupsData = await sock.groupFetchAllParticipating();
        if (groupsData && Object.keys(groupsData).length > 0) {
            groups = Object.values(groupsData).map(g => ({
                id: g.id,
                name: g.subject || g.name || 'بدون اسم'
            }));
        }
    } catch (e) {
        const allChats = await getAllChats(sock);
        groups = allChats.filter(c => {
            const id = c.id || c.jid;
            return id && id.endsWith('@g.us');
        }).map(c => ({
            id: c.id || c.jid,
            name: c.name || 'بدون اسم'
        }));
    }
    return groups;
}

router.post('/', async (req, res) => {
    const { sessionPhone, type, message, mediaUrl, mediaType } = req.body;
    const phone = formatPhone(sessionPhone);
    const session = stateModule.getSession(phone);
    
    if (!session || !session.isConnected) {
        return res.status(401).json({ success: false, message: 'الجلسة غير متصلة' });
    }
    
    const sock = session.sock;
    
    try {
        let targets = [];
        
        if (type === 'groups') {
            targets = await getAllGroups(sock);
        } else if (type === 'chats') {
            const allChats = await getAllChats(sock);
            targets = allChats.filter(c => {
                const id = c.id || c.jid;
                return id && !id.endsWith('@g.us') && !id.endsWith('@broadcast');
            }).map(c => ({
                id: c.id || c.jid,
                name: c.name || (c.id || c.jid).split('@')[0]
            }));
        } else { // all
            const groups = await getAllGroups(sock);
            const allChats = await getAllChats(sock);
            const privateChats = allChats.filter(c => {
                const id = c.id || c.jid;
                return id && !id.endsWith('@g.us') && !id.endsWith('@broadcast');
            }).map(c => ({
                id: c.id || c.jid,
                name: c.name || (c.id || c.jid).split('@')[0]
            }));
            targets = [...groups, ...privateChats];
        }
        
        if (targets.length === 0) {
            return res.json({ success: false, message: 'لا توجد جهات اتصال للنشر' });
        }
        
        let sentCount = 0;
        const delay = 2000;
        
        for (const target of targets) {
            try {
                const jid = target.id;
                
                if (mediaUrl) {
                    if (mediaType === 'image') {
                        await sock.sendMessage(jid, { 
                            image: { url: mediaUrl }, 
                            caption: message || '' 
                        });
                    } else if (mediaType === 'video') {
                        await sock.sendMessage(jid, { 
                            video: { url: mediaUrl }, 
                            caption: message || '' 
                        });
                    } else if (mediaType === 'document') {
                        // استخراج اسم الملف من الرابط
                        const fileName = mediaUrl.split('/').pop().split('?')[0] || 'file';
                        await sock.sendMessage(jid, { 
                            document: { url: mediaUrl },
                            mimetype: 'application/octet-stream',
                            fileName: fileName,
                            caption: message || ''
                        });
                    } else {
                        // افتراضي: إذا كان هناك رابط ولم يتم تحديد النوع نرسله كصورة
                        await sock.sendMessage(jid, { 
                            image: { url: mediaUrl }, 
                            caption: message || '' 
                        });
                    }
                } else if (message) {
                    await sock.sendMessage(jid, { text: message });
                } else {
                    continue;
                }
                
                sentCount++;
                logToApp(`📨 نشر إلى: ${target.name || jid}`, phone);
                
                await new Promise(r => setTimeout(r, delay));
            } catch (err) {
                logToApp(`❌ فشل النشر إلى ${target.id}: ${err.message}`, phone);
            }
        }
        
        res.json({ 
            success: true, 
            sent: sentCount, 
            total: targets.length,
            message: `تم النشر إلى ${sentCount} من أصل ${targets.length}`
        });
        
    } catch (err) {
        logToApp(`❌ فشل النشر الجماعي: ${err.message}`, phone);
        res.status(500).json({ success: false, message: err.message });
    }
});

module.exports = router;