// routes/commands.js — إدارة الأوامر (مع دعم aiPrompt و aiKey)
const express = require('express');
const router  = express.Router();
const fs      = require('fs');
const path    = require('path');
const { loadCommands, saveCommands } = require('../persistence');
const { PLUGINS_DIR } = require('../config');
const { loadPlugins } = require('../handler');

function getPluginCommands() {
    const result = [];
    if (!fs.existsSync(PLUGINS_DIR)) return result;
    const files = fs.readdirSync(PLUGINS_DIR).filter(f => f.endsWith('.js'));
    for (const file of files) {
        try {
            delete require.cache[require.resolve(path.join(PLUGINS_DIR, file))];
            const plugin = require(path.join(PLUGINS_DIR, file));
            const cmds   = Array.isArray(plugin) ? plugin : [plugin];
            for (const cmd of cmds) {
                if (!cmd.trigger || typeof cmd.handler !== 'function') continue;
                result.push({
                    id:            `plugin_${cmd.trigger}`,
                    trigger:       cmd.trigger,
                    description:   cmd.description || '',
                    actionType:    'plugin',
                    pluginTrigger: cmd.trigger,
                    isEnabled:     true,
                    usageCount:    0,
                    fromPlugin:    true,
                    pluginFile:    file,
                    groupOnly:     cmd.groupOnly || false,
                    adminOnly:     cmd.adminOnly || false,
                    createdAt:     new Date().toISOString(),
                    isOwnerCommand: file === 'owner.js'
                });
            }
        } catch {}
    }
    return result;
}

function mergeCommands() {
    const dbCmds     = loadCommands();
    const pluginCmds = getPluginCommands();
    const merged = [...pluginCmds];
    for (const dbCmd of dbCmds) {
        const idx = merged.findIndex(c => c.trigger === dbCmd.trigger && c.fromPlugin);
        if (idx !== -1) {
            const updated = { ...merged[idx], ...dbCmd, fromPlugin: true };
            if (dbCmd.deleted) { merged.splice(idx, 1); continue; }
            merged[idx] = updated;
        } else {
            merged.push(dbCmd);
        }
    }
    return merged.filter(cmd => !cmd.deleted);
}

router.get('/', (req, res) => {
    const commands = mergeCommands();
    res.json({ commands, total: commands.length });
});

router.post('/', (req, res) => {
    const commands = loadCommands();
    const actionType = req.body.actionType;
    if (actionType === 'button' || actionType === 'game') {
        return res.status(400).json({ error: 'نوع الأمر غير مدعوم' });
    }
    const newCmd = {
        id:            Date.now().toString(),
        trigger:       req.body.trigger?.toLowerCase().trim(),
        description:   req.body.description || '',
        actionType:    actionType || 'text',
        actionData:    req.body.actionData || req.body.response || '',
        response:      req.body.response || req.body.actionData || '',
        mediaUrl:      req.body.mediaUrl || null,
        caption:       req.body.caption || null,
        mediaType:     req.body.mediaType || null,
        pluginTrigger: req.body.pluginTrigger || null,
        isEnabled:     true,
        usageCount:    0,
        fromPlugin:    false,
        createdAt:     new Date().toISOString(),
        jokes:         req.body.jokes || null,
        goodbyeMessage: req.body.goodbyeMessage || null,
        showProfilePic: req.body.showProfilePic || false,
        aiPrompt:      req.body.aiPrompt || null,
        aiKey:         req.body.aiKey || null
    };
    if (!newCmd.trigger) return res.status(400).json({ error: 'trigger مطلوب' });
    if (commands.find(c => c.trigger === newCmd.trigger))
        return res.status(409).json({ error: 'الأمر موجود بالفعل' });
    commands.push(newCmd);
    saveCommands(commands);
    res.json({ success: true, command: newCmd });
});

router.put('/:id', (req, res) => {
    const commands = loadCommands();
    const idx = commands.findIndex(c => c.id === req.params.id);
    if (req.params.id.startsWith('plugin_')) {
        const pluginCmds = getPluginCommands();
        const target = pluginCmds.find(c => c.id === req.params.id);
        if (target && target.isOwnerCommand) {
            return res.status(403).json({ error: 'لا يمكن تعديل أوامر المالك' });
        }
        return res.status(403).json({ error: 'الأوامر المدمجة لا تقبل التعديل' });
    }
    if (idx === -1) return res.status(404).json({ error: 'أمر غير موجود' });
    const updatedAction = req.body.actionType;
    if (updatedAction === 'button' || updatedAction === 'game') {
        return res.status(400).json({ error: 'نوع الأمر غير مدعوم' });
    }
    commands[idx] = { ...commands[idx], ...req.body, id: req.params.id };
    saveCommands(commands);
    res.json({ success: true, command: commands[idx] });
});

router.delete('/:id', (req, res) => {
    const id = req.params.id;
    if (id.startsWith('plugin_')) {
        const pluginCmds = getPluginCommands();
        const target = pluginCmds.find(c => c.id === id);
        if (!target) return res.status(404).json({ error: 'أمر غير موجود' });
        if (target.isOwnerCommand) return res.status(403).json({ error: 'لا يمكن حذف أوامر المالك' });

        let cmds = loadCommands();
        const idx = cmds.findIndex(c => c.id === id);
        if (idx !== -1) {
            cmds[idx].deleted = true;
            cmds[idx].isEnabled = false;
        } else {
            cmds.push({
                id: `plugin_${target.trigger}`,
                trigger: target.trigger,
                isEnabled: false,
                fromPlugin: true,
                deleted: true,
                pluginFile: target.pluginFile,
                createdAt: new Date().toISOString()
            });
        }
        saveCommands(cmds);
        loadPlugins();
        return res.json({ success: true });
    }

    const dbCmds = loadCommands();
    const idx = dbCmds.findIndex(c => c.id === id);
    if (idx === -1) return res.status(404).json({ error: 'أمر غير موجود' });
    dbCmds.splice(idx, 1);
    saveCommands(dbCmds);
    res.json({ success: true });
});

router.patch('/:id/toggle', (req, res) => {
    const commands = loadCommands();
    const cmd = commands.find(c => c.id === req.params.id);
    if (req.params.id.startsWith('plugin_')) {
        const pluginCmds = getPluginCommands();
        const target = pluginCmds.find(c => c.id === req.params.id);
        if (!target) return res.status(404).json({ error: 'أمر غير موجود' });
        if (target.isOwnerCommand) return res.status(403).json({ error: 'لا يمكن تعطيل أوامر المالك' });

        let cmds = loadCommands();
        const idx = cmds.findIndex(c => c.id === req.params.id);
        if (idx !== -1) {
            cmds[idx].isEnabled = !cmds[idx].isEnabled;
        } else {
            cmds.push({
                id: req.params.id,
                trigger: target.trigger,
                isEnabled: false,
                fromPlugin: true,
                pluginFile: target.pluginFile,
                createdAt: new Date().toISOString()
            });
        }
        saveCommands(cmds);
        loadPlugins();
        const updated = mergeCommands().find(c => c.id === req.params.id);
        return res.json({ success: true, isEnabled: updated?.isEnabled || false });
    }
    if (!cmd) return res.status(404).json({ error: 'أمر غير موجود' });
    cmd.isEnabled = !cmd.isEnabled;
    saveCommands(commands);
    res.json({ success: true, isEnabled: cmd.isEnabled });
});

module.exports = router;