// =============================================
// plugins/stop.js — أمر إيقاف الألعاب
// =============================================
const gamesPlugin = (() => { try { return require('./games'); } catch { return null; } })();

module.exports = [
    {
        trigger: 'وقف',
        description: 'إيقاف أي لعبة أو تحدي نشط',
        handler: async ({ sock, from, senderJid }) => {
            if (!gamesPlugin) {
                await sock.sendMessage(from, { text: '⚠️ نظام الألعاب غير متوفر.' });
                return;
            }

            const activeGames = gamesPlugin.activeGames || new Map();
            const challenges = gamesPlugin.challenges || new Map();
            const rpsChallenges = gamesPlugin.rpsChallenges || new Map();

            let stopped = false;

            // إيقاف الألعاب الفردية (المرتبطة بالمحادثة)
            if (activeGames.has(from)) {
                activeGames.delete(from);
                stopped = true;
            }

            // إيقاف تحديات RPS النشطة (المرتبطة باللاعب)
            for (const [key, ch] of rpsChallenges) {
                if (ch.p1 === senderJid || ch.p2 === senderJid) {
                    rpsChallenges.delete(key);
                    stopped = true;
                }
            }

            // إيقاف تحديات قيد الانتظار (المرتبطة باللاعب)
            for (const [key, ch] of challenges) {
                if (ch.challenger === senderJid || ch.challenged === senderJid) {
                    challenges.delete(key);
                    stopped = true;
                }
            }

            await sock.sendMessage(from, {
                text: stopped ? '🛑 تم إيقاف اللعبة / التحدي الحالي.' : '⚠️ لا يوجد لعبة أو تحدي نشط لإيقافه.'
            });
        }
    }
];