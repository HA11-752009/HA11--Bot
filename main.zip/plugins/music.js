// =============================================
// plugins/music.js — تنزيل صوت وفيديو (yt-dlp + بحث تلقائي)
// =============================================
const fs = require('fs');
const path = require('path');
const { exec, execSync, spawn } = require('child_process');
const { logToApp } = require('../ws');

// تحميل yt-search للبحث النصي
let yts;
try {
    yts = require('yt-search');
} catch (e) {
    logToApp('⚠️ yt-search غير مثبت. قم بتثبيته: `npm install yt-search`');
}

// البحث عن ffmpeg
function findFfmpeg() {
    try {
        execSync('ffmpeg -version', { stdio: 'ignore', shell: true });
        return 'ffmpeg';
    } catch {}
    return null;
}
const FFMPEG = findFfmpeg();

const TEMP_DIR = path.join(__dirname, '..', 'temp_media');
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

function deleteFile(filePath) {
    try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch {}
}

/**
 * البحث التلقائي عن مسار yt-dlp أو تنزيله
 */
function findYtDlp() {
    const isWindows = process.platform === 'win32';
    
    // قائمة بالمسارات المحتملة
    const candidates = isWindows ? [
        path.join(process.env.USERPROFILE || '', 'AppData', 'Local', 'Programs', 'Python', 'Python311', 'Scripts', 'yt-dlp.exe'),
        path.join(process.env.USERPROFILE || '', 'AppData', 'Local', 'Programs', 'Python', 'Python312', 'Scripts', 'yt-dlp.exe'),
        'C:\\Python311\\Scripts\\yt-dlp.exe',
        'C:\\Python312\\Scripts\\yt-dlp.exe',
        path.join(__dirname, '..', 'bin', 'yt-dlp.exe'),
        'yt-dlp.exe'
    ] : [
        '/usr/local/bin/yt-dlp',
        '/usr/bin/yt-dlp',
        path.join(process.env.HOME || '', '.local', 'bin', 'yt-dlp'),
        path.join(__dirname, '..', 'bin', 'yt-dlp'),
        'yt-dlp'
    ];

    for (const candidate of candidates) {
        try {
            if (fs.existsSync(candidate)) {
                execSync(`"${candidate}" --version`, { stdio: 'ignore', shell: true });
                logToApp(`✅ تم العثور على yt-dlp في: ${candidate}`);
                return candidate;
            }
        } catch {}
    }

    // محاولة البحث باستخدام أمر `which` أو `where`
    try {
        const whichCmd = isWindows ? 'where yt-dlp' : 'which yt-dlp';
        const result = execSync(whichCmd, { encoding: 'utf8', shell: true }).trim();
        if (result) {
            logToApp(`✅ تم العثور على yt-dlp عبر ${whichCmd}: ${result.split('\n')[0]}`);
            return result.split('\n')[0];
        }
    } catch {}

    logToApp('❌ لم يتم العثور على yt-dlp. يرجى تثبيته من https://github.com/yt-dlp/yt-dlp');
    return null;
}

const YT_DLP = findYtDlp();

/**
 * تحويل نص البحث إلى رابط يوتيوب
 */
async function getYoutubeUrl(query) {
    if (query.startsWith('http')) return query;
    if (!yts) throw new Error('yt-search غير مثبت.');
    const results = await yts(query);
    const videos = results.videos;
    if (!videos || videos.length === 0) throw new Error('لم يتم العثور على نتائج.');
    logToApp(`✅ بحث: ${videos[0].title} (${videos[0].url})`);
    return videos[0].url;
}

/**
 * تنزيل الميديا (صوت أو فيديو) بجودة محددة
 */
async function downloadMedia(query, type, quality = 'best') {
    if (!YT_DLP) throw new Error('yt-dlp غير مثبت.');
    if (type === 'audio' && !FFMPEG) throw new Error('FFmpeg غير مثبت.');

    const videoUrl = await getYoutubeUrl(query);
    const stamp = Date.now();
    const ext = type === 'audio' ? 'mp3' : 'mp4';
    const filePath = path.join(TEMP_DIR, `${type}_${stamp}.${ext}`);

    let formatArg;
    if (type === 'audio') {
        formatArg = 'bestaudio';
    } else {
        if (quality === '720p') formatArg = 'best[height<=720][ext=mp4]';
        else if (quality === '480p') formatArg = 'best[height<=480][ext=mp4]';
        else if (quality === '360p') formatArg = 'best[height<=360][ext=mp4]';
        else formatArg = 'best[ext=mp4]';
    }

    const args = type === 'audio'
        ? ['-f', formatArg, '--extract-audio', '--audio-format', 'mp3', '-o', filePath]
        : ['-f', formatArg, '-o', filePath];

    logToApp(`📥 تنزيل (${type} / ${quality}): ${videoUrl}`);

    return new Promise((resolve, reject) => {
        const proc = spawn(YT_DLP, [...args, videoUrl], { shell: true });
        
        proc.on('close', (code) => {
            if (code !== 0) {
                reject(new Error(`yt-dlp exited with code ${code}`));
                return;
            }
            
            // استخراج العنوان
            const titleProc = spawn(YT_DLP, ['--print', 'title', videoUrl], { shell: true });
            let title = 'بدون عنوان';
            titleProc.stdout.on('data', (data) => { title = data.toString().trim(); });
            titleProc.on('close', () => {
                logToApp(`✅ تم التنزيل: ${title}`);
                resolve({ filePath, title });
            });
        });
        
        proc.on('error', (err) => reject(new Error(`فشل التنزيل: ${err.message}`)));
    });
}

// معالجات الأوامر (تبقى كما هي في الإصدار السابق مع استدعاء `downloadMedia`)
async function audioHandler({ sock, from, args }) { /* ... */ }
async function videoBestHandler({ sock, from, args }) { /* ... */ }
async function video720Handler({ sock, from, args }) { /* ... */ }
async function video480Handler({ sock, from, args }) { /* ... */ }
async function video360Handler({ sock, from, args }) { /* ... */ }

module.exports = [
    { trigger: 'موسيقى', description: 'تنزيل صوت mp3', handler: audioHandler },
    { trigger: 'فيديو', description: 'تنزيل فيديو (أفضل جودة)', handler: videoBestHandler },
    { trigger: 'فيديو720', description: 'تنزيل فيديو 720p', handler: video720Handler },
    { trigger: 'فيديو480', description: 'تنزيل فيديو 480p', handler: video480Handler },
    { trigger: 'فيديو360', description: 'تنزيل فيديو 360p', handler: video360Handler },
];