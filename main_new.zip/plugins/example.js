// =============================================
// plugins/example.js — قالب لإضافة أوامر جديدة
// =============================================
// انسخ هذا الملف وعدّله لإضافة أوامرك الخاصة
// كل أمر هو object فيه:
//   trigger     (string)   — الكلمة التي يكتبها المستخدم بعد البادئة
//   description (string)   — وصف اختياري
//   groupOnly   (boolean)  — اختياري: يعمل فقط في المجموعات
//   adminOnly   (boolean)  — اختياري: للمشرفين فقط
//   handler     (async fn) — الدالة المنفذة، تستقبل ctx:
//
// ctx = {
//   sock,           // Baileys socket
//   from,           // JID المحادثة/المجموعة
//   msg,            // كائن الرسالة الكامل
//   senderJid,      // JID المُرسِل
//   senderIsAdmin,  // boolean
//   settings,       // إعدادات البوت
//   isGroup,        // boolean
//   fullText,       // النص الكامل للرسالة
//   args,           // كلمات بعد الأمر  e.g. ['arg1','arg2']
//   prefix,         // البادئة الحالية e.g. '!'
// }
// =============================================

module.exports = [

    // مثال 1: أمر بسيط يرد بنص
    {
        trigger:     'مرحبا',
        description: 'رد تلقائي بالتحية',
        handler: async ({ sock, from, senderJid }) => {
            const name = senderJid.split('@')[0];
            await sock.sendMessage(from, { text: `👋 أهلاً وسهلاً ${name}!` });
        }
    },

    // مثال 2: أمر يأخذ argument
    {
        trigger:     'قول',
        description: 'البوت يقول أي نص',
        handler: async ({ sock, from, args }) => {
            const text = args.join(' ');
            if (!text) {
                await sock.sendMessage(from, { text: '❌ أكتب نص بعد الأمر' });
                return;
            }
            await sock.sendMessage(from, { text });
        }
    },

    // مثال 3: أمر للمشرفين فقط في المجموعات
    {
        trigger:     'تحذير',
        description: 'تحذير عضو في المجموعة',
        groupOnly:   true,
        adminOnly:   true,
        handler: async ({ sock, from, args, msg }) => {
            const ctxInfo  = msg.message?.extendedTextMessage?.contextInfo;
            const targetJid = ctxInfo?.participant;
            if (!targetJid) {
                await sock.sendMessage(from, { text: '⚠️ اقتبس رسالة العضو أولاً' });
                return;
            }
            const reason = args.join(' ') || 'مخالفة القوانين';
            await sock.sendMessage(from, {
                text: `⚠️ تحذير لـ @${targetJid.split('@')[0]}\nالسبب: ${reason}`,
                mentions: [targetJid]
            });
        }
    },

];
