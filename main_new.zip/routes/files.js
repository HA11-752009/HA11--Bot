// routes/files.js — إدارة الملفات المرفوعة (مع روابط معاينة محسّنة)
const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const UPLOADS_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOADS_DIR),
    filename: (req, file, cb) => {
        const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        cb(null, unique + ext);
    }
});
const upload = multer({ storage, limits: { fileSize: 100 * 1024 * 1024 } });

const MEDIA_TYPES = {
    image: ['.jpg','.jpeg','.png','.gif','.bmp','.webp','.svg','.ico'],
    video: ['.mp4','.mov','.avi','.mkv','.webm','.flv','.wmv','.m4v'],
    audio: ['.mp3','.wav','.ogg','.m4a','.aac','.flac'],
};

function getMediaType(filename) {
    const ext = path.extname(filename).toLowerCase();
    for (const [type, exts] of Object.entries(MEDIA_TYPES)) {
        if (exts.includes(ext)) return type;
    }
    return 'other';
}

// أيقونات محلية (ضعها في public/icons أو استخدم روابط أيقونات خارجية)
const PREVIEW_ICONS = {
    video: 'https://raw.githubusercontent.com/yourrepo/icons/main/video.png',
    audio: 'https://raw.githubusercontent.com/yourrepo/icons/main/audio.png',
    other: 'https://raw.githubusercontent.com/yourrepo/icons/main/file.png',
};

router.get('/', (req, res) => {
    try {
        const files = fs.readdirSync(UPLOADS_DIR).map(filename => {
            const filePath = path.join(UPLOADS_DIR, filename);
            const stats = fs.statSync(filePath);
            const baseUrl = `${req.protocol}://${req.get('host')}`;
            const type = getMediaType(filename);
            let previewUrl;
            if (type === 'image') {
                // للصور نعرضها مباشرة
                previewUrl = `${baseUrl}/uploads/${filename}`;
            } else {
                previewUrl = PREVIEW_ICONS[type] || PREVIEW_ICONS.other;
            }
            return {
                name: filename,
                size: stats.size,
                created: stats.birthtime,
                modified: stats.mtime,
                url: `${baseUrl}/uploads/${filename}`,
                path: filePath,
                type,
                previewUrl
            };
        });
        res.json({ files, total: files.length });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST /api/files — رفع ملف
router.post('/', upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ success: false, error: 'لم يتم رفع ملف' });
    const baseUrl = `${req.protocol}://${req.get('host')}`;
    const fileUrl = `${baseUrl}/uploads/${req.file.filename}`;
    res.json({ success: true, url: fileUrl, filename: req.file.filename });
});

// PUT /api/files/:filename — إعادة تسمية
router.put('/:filename', (req, res) => {
    const oldName = req.params.filename;
    const newName = req.body.newName;
    if (!newName) return res.status(400).json({ error: 'newName مطلوب' });
    const oldPath = path.join(UPLOADS_DIR, oldName);
    const newPath = path.join(UPLOADS_DIR, newName);
    if (!fs.existsSync(oldPath)) return res.status(404).json({ error: 'الملف غير موجود' });
    if (fs.existsSync(newPath)) return res.status(409).json({ error: 'اسم الملف موجود بالفعل' });
    try {
        fs.renameSync(oldPath, newPath);
        const baseUrl = `${req.protocol}://${req.get('host')}`;
        res.json({ success: true, oldName, newName, url: `${baseUrl}/uploads/${newName}` });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE /api/files/:filename — حذف ملف
router.delete('/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(UPLOADS_DIR, filename);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'الملف غير موجود' });
    try {
        fs.unlinkSync(filePath);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;