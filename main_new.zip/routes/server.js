// routes/server.js — إدارة السيرفرات (تشغيل سكريبتات، إيقاف تلقائي، تحرير، نسخ/نقل)
const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const multer = require('multer');
const { broadcastTaskLog } = require('../ws');
const axios = require('axios');

const SERVERS_DIR = path.join(__dirname, '..', 'servers');
if (!fs.existsSync(SERVERS_DIR)) fs.mkdirSync(SERVERS_DIR, { recursive: true });

const defaultPath = path.join(SERVERS_DIR, 'default');
if (!fs.existsSync(defaultPath)) {
    fs.mkdirSync(defaultPath, { recursive: true });
    fs.writeFileSync(path.join(defaultPath, 'README.txt'), 'مرحباً بك في سيرفر HA11!');
}

const runningTasks = new Map();
const watchIntervals = new Map();

// ========== نظام الإيقاف التلقائي ==========
const FIREBASE_URL = process.env.FIREBASE_DATABASE_URL || 'https://your-project.firebaseio.com';

async function checkCodeValidity(code) {
    try {
        const response = await axios.get(`${FIREBASE_URL}/server_codes/${code}.json`);
        const data = response.data;
        if (!data) return false;
        if (!data.active) return false;
        if (data.activated_at && data.durationSeconds) {
            const expiresAt = data.activated_at + data.durationSeconds * 1000;
            return Date.now() <= expiresAt;
        }
        if (data.activated_at && data.duration_days) {
            const expiresAt = data.activated_at + data.duration_days * 86400000;
            return Date.now() <= expiresAt;
        }
        return true;
    } catch (e) {
        return true;
    }
}

function killAllTasks(serverId) {
    const tasks = runningTasks.get(serverId);
    if (tasks) {
        for (const [, child] of tasks) {
            try { child.kill('SIGTERM'); } catch (e) {}
        }
        runningTasks.delete(serverId);
    }
    if (watchIntervals.has(serverId)) {
        clearInterval(watchIntervals.get(serverId));
        watchIntervals.delete(serverId);
    }
}

function startWatchingServer(serverId, code) {
    if (watchIntervals.has(serverId)) return;
    const interval = setInterval(async () => {
        const valid = await checkCodeValidity(code);
        if (!valid) {
            killAllTasks(serverId);
        }
    }, 5000);
    watchIntervals.set(serverId, interval);
}

// ========== نقاط النهاية ==========
router.get('/files/:serverId', (req, res) => {
    const serverId = req.params.serverId;
    const serverPath = path.join(SERVERS_DIR, serverId);
    if (!fs.existsSync(serverPath)) {
        fs.mkdirSync(serverPath, { recursive: true });
        fs.writeFileSync(path.join(serverPath, 'README.txt'), 'مرحباً بك في سيرفر HA11!');
    }
    const relativePath = req.query.path || '';
    const fullPath = path.join(serverPath, relativePath);
    if (!fullPath.startsWith(serverPath)) return res.status(403).json({ error: 'محظور' });

    if (fs.statSync(fullPath).isDirectory()) {
        const items = fs.readdirSync(fullPath).map(name => {
            const itemPath = path.join(fullPath, name);
            const stats = fs.statSync(itemPath);
            return { name, isDirectory: stats.isDirectory(), size: stats.size, modified: stats.mtime };
        });
        res.json({ path: relativePath, items });
    } else {
        const content = fs.readFileSync(fullPath, 'utf8');
        res.json({ path: relativePath, content });
    }
});

router.post('/files/:serverId', (req, res) => {
    const serverId = req.params.serverId;
    const serverPath = path.join(SERVERS_DIR, serverId);
    if (!fs.existsSync(serverPath)) fs.mkdirSync(serverPath, { recursive: true });
    const relativePath = req.query.path || '';
    const fullPath = path.join(serverPath, relativePath);
    const { name, content, isDirectory } = req.body;
    if (isDirectory) fs.mkdirSync(path.join(fullPath, name), { recursive: true });
    else fs.writeFileSync(path.join(fullPath, name), content || '');
    res.json({ success: true });
});

router.put('/files/:serverId', (req, res) => {
    const serverId = req.params.serverId;
    const serverPath = path.join(SERVERS_DIR, serverId);
    const relativePath = req.query.path || '';
    const fullPath = path.join(serverPath, relativePath);
    if (!fullPath.startsWith(serverPath)) return res.status(403).json({ error: 'محظور' });
    fs.writeFileSync(fullPath, req.body.content || '');
    res.json({ success: true });
});

router.put('/rename/:serverId', (req, res) => {
    const serverId = req.params.serverId;
    const serverPath = path.join(SERVERS_DIR, serverId);
    const { oldPath, newPath } = req.body;
    const oldFull = path.join(serverPath, oldPath);
    const newFull = path.join(serverPath, newPath);
    if (!fs.existsSync(oldFull)) return res.status(404).json({ error: 'غير موجود' });
    fs.renameSync(oldFull, newFull);
    res.json({ success: true });
});

router.delete('/files/:serverId', (req, res) => {
    const serverId = req.params.serverId;
    const serverPath = path.join(SERVERS_DIR, serverId);
    const relativePath = req.query.path || '';
    const fullPath = path.join(serverPath, relativePath);
    if (!fullPath.startsWith(serverPath)) return res.status(403).json({ error: 'محظور' });
    if (fs.statSync(fullPath).isDirectory()) fs.rmSync(fullPath, { recursive: true });
    else fs.unlinkSync(fullPath);
    res.json({ success: true });
});

router.post('/run/:serverId', (req, res) => {
    const serverId = req.params.serverId;
    const serverPath = path.join(SERVERS_DIR, serverId);
    const { file, type, code } = req.body;
    const filePath = path.join(serverPath, file);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'الملف غير موجود' });

    const taskId = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
    const ext = path.extname(filePath).toLowerCase();
    let detectedType = type;
    if (ext === '.py') detectedType = 'python';
    else if (['.js','.mjs','.cjs'].includes(ext)) detectedType = 'node';

    let installCmd = '';
    if (detectedType === 'node' && fs.existsSync(path.join(serverPath, 'package.json'))) {
        installCmd = 'npm install && ';
    } else if (detectedType === 'python' && fs.existsSync(path.join(serverPath, 'requirements.txt'))) {
        installCmd = 'pip install -r requirements.txt || pip3 install -r requirements.txt && ';
    }

    let runCmd = detectedType === 'python'
        ? `python3 "${filePath}" 2>&1 || python "${filePath}" 2>&1`
        : `node "${filePath}" 2>&1`;

    const fullCmd = installCmd + runCmd;
    const child = exec(fullCmd, { cwd: serverPath, timeout: 0, maxBuffer: 10 * 1024 * 1024 });

    if (!runningTasks.has(serverId)) runningTasks.set(serverId, new Map());
    runningTasks.get(serverId).set(taskId, child);

    if (code) startWatchingServer(serverId, code);

    child.stdout.on('data', (data) => broadcastTaskLog(taskId, 'log', data.toString()));
    child.stderr.on('data', (data) => broadcastTaskLog(taskId, 'error', data.toString()));

    child.on('close', (exitCode) => {
        const tasks = runningTasks.get(serverId);
        if (tasks) tasks.delete(taskId);
        broadcastTaskLog(taskId, 'end', exitCode === 0 ? 'تم التنفيذ بنجاح' : `انتهى مع كود ${exitCode}`);
    });

    child.on('error', (err) => {
        const tasks = runningTasks.get(serverId);
        if (tasks) tasks.delete(taskId);
        broadcastTaskLog(taskId, 'error', err.message);
        broadcastTaskLog(taskId, 'end', 'فشل');
    });

    res.json({ taskId, status: 'started' });
});

router.post('/kill/:taskId', (req, res) => {
    const taskId = req.params.taskId;
    for (const [, tasks] of runningTasks) {
        const child = tasks.get(taskId);
        if (child) {
            child.kill('SIGTERM');
            tasks.delete(taskId);
            broadcastTaskLog(taskId, 'end', 'تم الإيقاف بواسطة المستخدم');
            return res.json({ success: true });
        }
    }
    res.status(404).json({ error: 'المهمة غير موجودة' });
});

router.post('/kill-all/:serverId', (req, res) => {
    killAllTasks(req.params.serverId);
    res.json({ success: true });
});

const upload = multer({ dest: path.join(SERVERS_DIR, 'temp_uploads') });
router.post('/upload/:serverId', upload.single('file'), (req, res) => {
    const serverId = req.params.serverId;
    const serverPath = path.join(SERVERS_DIR, serverId);
    if (!fs.existsSync(serverPath)) fs.mkdirSync(serverPath, { recursive: true });
    const destPath = path.join(serverPath, req.file.originalname);
    fs.renameSync(req.file.path, destPath);
    res.json({ success: true });
});

router.post('/copy/:serverId', (req, res) => {
    const serverId = req.params.serverId;
    const serverPath = path.join(SERVERS_DIR, serverId);
    const { sourcePath, destPath } = req.body;
    const sourceFull = path.join(serverPath, sourcePath);
    const destFull = path.join(serverPath, destPath);
    if (!fs.existsSync(sourceFull)) return res.status(404).json({ error: 'المصدر غير موجود' });
    if (fs.existsSync(destFull)) return res.status(409).json({ error: 'الوجهة موجودة' });
    try {
        if (fs.statSync(sourceFull).isDirectory()) {
            fs.cpSync(sourceFull, destFull, { recursive: true });
        } else {
            const destDir = path.dirname(destFull);
            if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
            fs.copyFileSync(sourceFull, destFull);
        }
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

router.post('/move/:serverId', (req, res) => {
    const serverId = req.params.serverId;
    const serverPath = path.join(SERVERS_DIR, serverId);
    const { sourcePath, destPath } = req.body;
    const sourceFull = path.join(serverPath, sourcePath);
    const destFull = path.join(serverPath, destPath);
    if (!fs.existsSync(sourceFull)) return res.status(404).json({ error: 'المصدر غير موجود' });
    if (fs.existsSync(destFull)) return res.status(409).json({ error: 'الوجهة موجودة' });
    try {
        const destDir = path.dirname(destFull);
        if (!fs.existsSync(destDir)) fs.mkdirSync(destDir, { recursive: true });
        fs.renameSync(sourceFull, destFull);
        res.json({ success: true });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;