// =============================================
// plugins/games.js — جميع الألعاب التفاعلية (تحدي حقيقي)
// =============================================
const { logToApp } = require('../ws');

const activeGames = new Map();   // ألعاب فردية
const challenges = new Map();    // تحديات قيد الانتظار
const rpsChallenges = new Map(); // تحديات RPS نشطة (لاعب ضد لاعب)
const CHALLENGE_TIMEOUT = 60_000;

function getRandom(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function extractTarget(msg) {
    const c = msg.message?.extendedTextMessage?.contextInfo;
    return c?.participant || c?.mentionedJid?.[0] || null;
}
function chKey(from, a, b) { return `${from}::${a}::${b}`; }

// ── معالجات الألعاب الفردية ─────────────────
async function handleGameMessage(sock, from, msg, senderJid, fullText) {
    const game = activeGames.get(from);
    if (!game) return false;

    switch (game.type) {
        case 'number': {
            const guess = parseInt(fullText.split(/\s+/)[1]);
            if (isNaN(guess)) break;
            game.attempts++;
            if (guess === game.secret) {
                activeGames.delete(from);
                await sock.sendMessage(from, { text: `🎉 *أحسنت!* الرقم ${game.secret} (في ${game.attempts} محاولة)` });
            } else {
                const hint = guess < game.secret ? '⬆️ أكبر' : '⬇️ أصغر';
                await sock.sendMessage(from, { text: `❌ غلط! ${hint} (محاولة ${game.attempts})` });
            }
            return true;
        }
        case 'trivia': {
            const answer = fullText.trim().toLowerCase();
            if (answer.includes(game.answer.toLowerCase())) {
                activeGames.delete(from);
                await sock.sendMessage(from, { text: `✅ *صحيح!* ${game.answer}` });
            } else {
                await sock.sendMessage(from, { text: `❌ خطأ! حاول مرة أخرى.` });
            }
            return true;
        }
        case 'word': {
            const guess = fullText.trim();
            if (guess === game.answer) {
                activeGames.delete(from);
                await sock.sendMessage(from, { text: `✅ *صح!* الكلمة: ${game.answer}` });
            } else {
                await sock.sendMessage(from, { text: `❌ غلط! تلميح: ${game.answer.length} حروف.` });
            }
            return true;
        }
        case 'celebrity': {
            const guess = fullText.trim();
            if (guess.includes(game.name)) {
                activeGames.delete(from);
                await sock.sendMessage(from, { text: `✅ *صح!* أنا ${game.name}` });
            } else {
                game.hintIdx = (game.hintIdx || 0) + 1;
                if (game.hintIdx >= game.hints.length) {
                    activeGames.delete(from);
                    await sock.sendMessage(from, { text: `😞 خلصت التلميحات. كنت ${game.name}` });
                } else {
                    await sock.sendMessage(from, { text: `❌ غلط! تلميح جديد: ${game.hints[game.hintIdx]}` });
                }
            }
            return true;
        }
        case 'math': {
            const answer = parseFloat(fullText.trim());
            if (Math.abs(answer - game.answer) < 0.01) {
                activeGames.delete(from);
                await sock.sendMessage(from, { text: `✅ *صح!* = ${game.answer}` });
            } else {
                await sock.sendMessage(from, { text: `❌ خطأ! حاول مجدداً.` });
            }
            return true;
        }
    }
    return false;
}

// ── تحدي حجر-ورقة-مقص تفاعلي ───────────────
async function handleRPSChallenge(sock, from, msg, senderJid, fullText) {
    for (const [key, ch] of rpsChallenges) {
        if (ch.p1 === senderJid || ch.p2 === senderJid) {
            const choice = fullText.trim().toLowerCase();
            const valid = ['حجر','ورقة','مقص'];
            if (!valid.includes(choice)) {
                await sock.sendMessage(from, { text: `⏳ اختيار غير صحيح. أرسل حجر/ورقة/مقص.` });
                return true;
            }

            if (ch.p1 === senderJid && !ch.p1Choice) {
                ch.p1Choice = choice;
                await sock.sendMessage(from, { text: `✅ @${senderJid.split('@')[0]} اختار.`, mentions: [senderJid] });
            } else if (ch.p2 === senderJid && !ch.p2Choice) {
                ch.p2Choice = choice;
                await sock.sendMessage(from, { text: `✅ @${senderJid.split('@')[0]} اختار.`, mentions: [senderJid] });
            } else {
                await sock.sendMessage(from, { text: `⏳ لقد اخترت بالفعل.` });
                return true;
            }

            if (ch.p1Choice && ch.p2Choice) {
                const c1 = ch.p1Choice, c2 = ch.p2Choice;
                let winner = null;
                if (c1 !== c2) {
                    if ((c1==='حجر'&&c2==='مقص')||(c1==='مقص'&&c2==='ورقة')||(c1==='ورقة'&&c2==='حجر')) winner = ch.p1;
                    else winner = ch.p2;
                }
                if (winner === ch.p1) ch.scores[0]++;
                else if (winner === ch.p2) ch.scores[1]++;

                const n1 = ch.p1.split('@')[0], n2 = ch.p2.split('@')[0];
                const roundMsg = `⚔️ ج${ch.round}: ${c1} 🆚 ${c2} → ${winner ? (winner===ch.p1?n1:n2)+' فاز' : 'تعادل'}`;
                ch.round++;
                ch.p1Choice = null;
                ch.p2Choice = null;

                if (ch.round > 3) {
                    rpsChallenges.delete(key);
                    let final = `🏆 *نتيجة تحدي حجر-ورقة-مقص*\n\n`;
                    final += `📊 ${n1} ${ch.scores[0]} - ${ch.scores[1]} ${n2}\n`;
                    if (ch.scores[0] > ch.scores[1]) final += `🥇 البطل: ${n1}`;
                    else if (ch.scores[1] > ch.scores[0]) final += `🥇 البطل: ${n2}`;
                    else final += `🤝 تعادل عام`;
                    await sock.sendMessage(from, { text: final, mentions: [ch.p1, ch.p2] });
                } else {
                    await sock.sendMessage(from, {
                        text: roundMsg + `\n🔁 الجولة ${ch.round}: أرسل @${n1} و @${n2} اختياركما.`,
                        mentions: [ch.p1, ch.p2]
                    });
                }
            }
            return true;
        }
    }
    return false;
}

// ── بيانات الألعاب ───────────────────────
const trivia = [
    { q: '🌍 عاصمة فرنسا؟', a: 'باريس', options: ['لندن','باريس','برلين','مدريد'] },
    { q: '🔢 أيام السنة الكبيسة؟', a: '366', options: ['365','366','367','364'] },
    { q: '🌊 أكبر محيط؟', a: 'المحيط الهادئ', options: ['الأطلسي','الهندي','الهادئ','المتوسط'] },
    { q: '⚽ البرازيل كم كأس عالم؟', a: '5', options: ['3','4','5','6'] },
    { q: '🦈 أكبر سمكة؟', a: 'القرش الحوتي', options: ['التونة','الأبيض','الحوتي','البلطي'] },
    { q: '🌙 بعد القمر؟', a: '384,400 كم', options: ['100,000','250,000','384,400','500,000'] },
];
const words = ['مصر','القاهرة','النيل','الشمس','القمر','النجوم','الأرض','السماء','الجبل','التفاح','الموز','الكمبيوتر'];
const celebs = [
    { name: 'محمد صلاح', hints: ['لاعب كرة قدم','مصري','في ليفربول','الملك المصري'] },
    { name: 'ستيف جوبز', hints: ['أسس Apple','أمريكي','توفي 2011','عبقري'] },
    { name: 'أم كلثوم', hints: ['مغنية','مصرية','كوكب الشرق','صوت خالد'] },
];

// ============== الأوامر ==============
const commands = [
    {
        trigger: 'قبل',
        description: 'الموافقة على تحدي لعبة',
        handler: async ({ sock, from, senderJid }) => {
            for (const [key, ch] of challenges) {
                if (ch.challenged === senderJid && key.startsWith(from + '::')) {
                    challenges.delete(key);
                    if (ch.game === 'احجار') {
                        const key2 = `${from}::${ch.challenger}::${ch.challenged}`;
                        rpsChallenges.set(key2, {
                            round: 1, p1: ch.challenger, p2: ch.challenged,
                            p1Choice: null, p2Choice: null, scores: [0,0]
                        });
                        const n1 = ch.challenger.split('@')[0], n2 = ch.challenged.split('@')[0];
                        await sock.sendMessage(from, {
                            text: `🎮 *تحدي حجر-ورقة-مقص* بين @${n1} و @${n2}!\n⚔️ الجولة 1: أرسل كل منكما اختياره (حجر/ورقة/مقص).`,
                            mentions: [ch.challenger, ch.challenged]
                        });
                    }
                    return;
                }
            }
            await sock.sendMessage(from, { text: '⚠️ لا يوجد تحدي موجه إليك.' });
        }
    },
    {
        trigger: 'رفض',
        description: 'رفض تحدي',
        handler: async ({ sock, from, senderJid }) => {
            for (const [key, ch] of challenges) {
                if (ch.challenged === senderJid && key.startsWith(from + '::')) {
                    challenges.delete(key);
                    await sock.sendMessage(from, {
                        text: `❌ @${senderJid.split('@')[0]} رفض التحدي.`,
                        mentions: [senderJid, ch.challenger]
                    });
                    return;
                }
            }
            await sock.sendMessage(from, { text: '⚠️ لا يوجد تحدي موجه إليك.' });
        }
    },
    {
        trigger: 'احجار',
        description: 'تحدي حجر-ورقة-مقص ✂️',
        handler: async ({ sock, from, msg, args, senderJid }) => {
            const target = extractTarget(msg);
            
            // 1. لو فيه منشن = تحدي لاعب آخر
            if (target && from.endsWith('@g.us')) {
                // منع تحدي النفس
                if (target === senderJid) {
                    await sock.sendMessage(from, { text: '❌ لا يمكنك تحدي نفسك! 😅' });
                    return;
                }
                const key = chKey(from, senderJid, target);
                if (challenges.has(key)) {
                    await sock.sendMessage(from, { text: '⏳ تحدي قائم بالفعل.' });
                    return;
                }
                challenges.set(key, { challenger: senderJid, challenged: target, game: 'احجار', at: Date.now() });
                await sock.sendMessage(from, {
                    text: `🎮 تحدي *حجر-ورقة-مقص* من @${senderJid.split('@')[0]} إلى @${target.split('@')[0]}! اكتب *قبل* للقبول.`,
                    mentions: [senderJid, target]
                });
                setTimeout(() => challenges.delete(key), CHALLENGE_TIMEOUT);
                return;
            }

            // 2. لعبة فردية ضد البوت (اختياري - لما تكتب !احجار حجر)
            const userChoice = (args[0] || '').toLowerCase();
            const validChoices = { 'حجر': '🪨', 'ورقة': '📄', 'مقص': '✂️' };
            
            if (!userChoice || !validChoices[userChoice]) {
                await sock.sendMessage(from, { 
                    text: '❌ استخدام فردي: !احجار <حجر/ورقة/مقص>\nأو للتحدي: !احجار مع منشن على الشخص.' 
                });
                return;
            }

            const botChoice = getRandom(Object.keys(validChoices));
            let result = '🤝 تعادل!';
            if (userChoice !== botChoice) {
                if ((userChoice === 'حجر' && botChoice === 'مقص') || 
                    (userChoice === 'مقص' && botChoice === 'ورقة') || 
                    (userChoice === 'ورقة' && botChoice === 'حجر')) {
                    result = '🎉 انت كسبت!';
                } else {
                    result = '😅 البوت كسب!';
                }
            }

            await sock.sendMessage(from, {
                text: `✂️🪨📄 *حجر ورقة مقص*\n\n` +
                      `انت: ${validChoices[userChoice]} ${userChoice}\n` +
                      `البوت: ${validChoices[botChoice]} ${botChoice}\n\n` +
                      `🏆 ${result}`
            });
        }
    },
    {
        trigger: 'خمن',
        description: 'تخمين الرقم 🎯',
        handler: async ({ sock, from }) => {
            const secret = Math.floor(Math.random() * 100) + 1;
            activeGames.set(from, { type: 'number', secret, attempts: 0 });
            await sock.sendMessage(from, { text: '🎯 *تخمين الرقم*\nفكرت في رقم من 1 إلى 100. اكتب !خمن <رقم>' });
        }
    },
    {
        trigger: 'تريفيا',
        description: 'سؤال معلومات عامة 🧠',
        handler: async ({ sock, from }) => {
            const q = getRandom(trivia);
            activeGames.set(from, { type: 'trivia', answer: q.a });
            const opts = q.options.map((o, i) => `${i+1}️⃣ ${o}`).join('\n');
            await sock.sendMessage(from, { text: `🧠 *تريفيا:*\n${q.q}\n\n${opts}` });
        }
    },
    {
        trigger: 'مقلوب',
        description: 'احزر الكلمة المقلوبة 🔄',
        handler: async ({ sock, from }) => {
            const word = getRandom(words);
            activeGames.set(from, { type: 'word', answer: word });
            await sock.sendMessage(from, { text: `🔄 *كلمة مقلوبة:* \`${word.split('').reverse().join('')}\`` });
        }
    },
    {
        trigger: 'شخصية',
        description: 'احزر الشخصية 🎭',
        handler: async ({ sock, from }) => {
            const c = getRandom(celebs);
            activeGames.set(from, { type: 'celebrity', name: c.name, hints: c.hints, hintIdx: 0 });
            await sock.sendMessage(from, { text: `🎭 *من أنا؟*\n💡 ${c.hints[0]}` });
        }
    },
    {
        trigger: 'من_انا',
        description: 'احزر الشخصية 🎭',
        handler: async (ctx) => {
            const c = getRandom(celebs);
            activeGames.set(ctx.from, { type: 'celebrity', name: c.name, hints: c.hints, hintIdx: 0 });
            await ctx.sock.sendMessage(ctx.from, { text: `🎭 *من أنا؟*\n💡 ${c.hints[0]}` });
        }
    },
    {
        trigger: 'احسب',
        description: 'مسألة رياضية سريعة ➕',
        handler: async ({ sock, from }) => {
            const a = Math.floor(Math.random() * 50) + 1;
            const b = Math.floor(Math.random() * 20) + 1;
            const op = getRandom(['+', '-', '*']);
            const answer = op === '+' ? a + b : op === '-' ? a - b : a * b;
            activeGames.set(from, { type: 'math', answer, start: Date.now() });
            await sock.sendMessage(from, { text: `➕ احسب: *${a} ${op} ${b} = ?*` });
        }
    },
];

// تصدير
module.exports = commands;
module.exports.handleGameMessage = handleGameMessage;
module.exports.handleRPSChallenge = handleRPSChallenge;
module.exports.activeGames = activeGames;
module.exports.challenges = challenges;
module.exports.rpsChallenges = rpsChallenges;