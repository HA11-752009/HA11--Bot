import os
os.system("pwd && whatis && uname -a ")
