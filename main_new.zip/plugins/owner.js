// =============================================
// plugins/owner.js — أوامر المالك (للتحكم في البوت)
// =============================================
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const { exec } = require('child_process');
const { logToApp } = require('../ws');
const { loadSettings, saveSettings } = require('../persistence');
const { startBot, stopBot } = require('../bot');
const stateModule = require('../state');

// الحصول على رقم المالك من الإعدادات
function getOwnerNumber(settings) {
    return settings.botOwner || settings.welcomeNumber || '';
}

// التحقق من أن المرسل هو المالك (يدعم JID مثل 201003128866:2@s.whatsapp.net)
function isOwner(senderJid, settings) {
    const owner = getOwnerNumber(settings);
    if (!owner) return false;
    const senderNumber = senderJid.split('@')[0].split(':')[0];
    return senderNumber === owner;
}

// أوامر المالك
const commands = [
    {
        trigger: 'تحديث_مالك',
        description: 'تحديث رقم المالك إلى الرقم الحالي',
        handler: async ({ sock, from, senderJid }) => {
            const senderNumber = senderJid.split('@')[0].split(':')[0];
            const currentSettings = loadSettings();
            currentSettings.botOwner = senderNumber;
            saveSettings(currentSettings);
            await sock.sendMessage(from, { text: `✅ تم تحديث رقم المالك إلى: ${senderNumber}` });
            logToApp(`👑 تم تحديث المالك إلى ${senderNumber} بواسطة ${senderJid}`);
        }
    },
    {
        trigger: 'تعديل',
        description: 'تعديل إعدادات البوت (للمالك فقط)',
        handler: async ({ sock, from, args, senderJid, settings }) => {
            if (!isOwner(senderJid, settings)) {
                await sock.sendMessage(from, { text: '❌ هذا الأمر للمالك فقط!' });
                return;
            }

            if (args.length < 2) {
                await sock.sendMessage(from, { 
                    text: `❌ استخدم: ${settings.commandPrefix}تعديل <المفتاح> <القيمة>\n` +
                          `مفاتيح متاحة: botName, commandPrefix, welcomeMessage, goodbyeMessage, autoDeleteLinks, antiSpam, ...`
                });
                return;
            }

            const key = args[0];
            const value = args.slice(1).join(' ');
            
            const allowedKeys = [
                'botName', 'commandPrefix', 'welcomeMessage', 'goodbyeMessage',
                'welcomeMediaUrl', 'helpImageUrl', 'botAvatar', 'botOwner',
                'autoDeleteLinks', 'deleteAdminLinks', 'autoAcceptJoinRequests',
                'antiSpam', 'antiSpamLimit', 'antiSpamAction',
                'maxWarnings', 'warningAction', 'gamesEnabled', 'musicEnabled'
            ];

            if (!allowedKeys.includes(key)) {
                await sock.sendMessage(from, { text: `❌ مفتاح غير مسموح به: ${key}` });
                return;
            }

            let parsedValue = value;
            if (value.toLowerCase() === 'true') parsedValue = true;
            else if (value.toLowerCase() === 'false') parsedValue = false;
            else if (!isNaN(value) && value.trim() !== '') parsedValue = parseInt(value);

            const currentSettings = loadSettings();
            currentSettings[key] = parsedValue;
            saveSettings(currentSettings);

            await sock.sendMessage(from, { text: `✅ تم تعديل *${key}* إلى: ${parsedValue}` });
            logToApp(`⚙️ المالك ${senderJid} عدل ${key} إلى ${parsedValue}`);
        }
    },
    {
        trigger: 'رفع_وسائط',
        description: 'رفع صورة/فيديو من رابط إلى السيرفر (للمالك)',
        handler: async ({ sock, from, args, senderJid, settings }) => {
            if (!isOwner(senderJid, settings)) {
                await sock.sendMessage(from, { text: '❌ هذا الأمر للمالك فقط!' });
                return;
            }

            if (args.length < 2) {
                await sock.sendMessage(from, { text: `❌ استخدم: ${settings.commandPrefix}رفع_وسائط <نوع> <رابط>\nالنوع: welcome, help, avatar` });
                return;
            }

            const type = args[0];
            const url = args[1];

            if (!['welcome', 'help', 'avatar'].includes(type)) {
                await sock.sendMessage(from, { text: '❌ النوع يجب أن يكون: welcome, help, avatar' });
                return;
            }

            try {
                const response = await axios.get(url, { responseType: 'arraybuffer' });
                const buffer = Buffer.from(response.data);
                
                let ext = '.jpg';
                const contentType = response.headers['content-type'];
                if (contentType) {
                    if (contentType.includes('video')) ext = '.mp4';
                    else if (contentType.includes('png')) ext = '.png';
                    else if (contentType.includes('gif')) ext = '.gif';
                } else if (url.endsWith('.mp4')) ext = '.mp4';
                
                const filename = `${type}_${Date.now()}${ext}`;
                const uploadsDir = path.join(__dirname, '..', 'uploads');
                if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
                const filePath = path.join(uploadsDir, filename);
                fs.writeFileSync(filePath, buffer);

                const config = require('../config');
                const fileUrl = `http://localhost:${config.HTTP_PORT}/uploads/${filename}`;

                const currentSettings = loadSettings();
                if (type === 'welcome') currentSettings.welcomeMediaUrl = fileUrl;
                else if (type === 'help') currentSettings.helpImageUrl = fileUrl;
                else if (type === 'avatar') currentSettings.botAvatar = fileUrl;
                saveSettings(currentSettings);

                await sock.sendMessage(from, { text: `✅ تم رفع الوسائط وحفظها كـ ${type}` });
            } catch (err) {
                await sock.sendMessage(from, { text: `❌ فشل رفع الوسائط: ${err.message}` });
            }
        }
    },
    {
        trigger: 'اعادة',
        description: 'إعادة تشغيل البوت (للمالك)',
        handler: async ({ sock, from, senderJid, settings, session }) => {
            if (!isOwner(senderJid, settings)) {
                await sock.sendMessage(from, { text: '❌ هذا الأمر للمالك فقط!' });
                return;
            }

            await sock.sendMessage(from, { text: '🔄 جاري إعادة تشغيل البوت...' });
            
            const phone = session.currentPhone;
            await stopBot(phone);
            setTimeout(() => startBot(phone), 2000);
        }
    },
    {
        trigger: 'ايقاف_بوت',
        description: 'إيقاف البوت (للمالك)',
        handler: async ({ sock, from, senderJid, settings, session }) => {
            if (!isOwner(senderJid, settings)) {
                await sock.sendMessage(from, { text: '❌ هذا الأمر للمالك فقط!' });
                return;
            }

            await sock.sendMessage(from, { text: '🛑 جاري إيقاف البوت...' });
            await stopBot(session.currentPhone);
        }
    },
    {
        trigger: 'تشغيل_بوت',
        description: 'تشغيل البوت (للمالك)',
        handler: async ({ sock, from, senderJid, settings, session }) => {
            if (!isOwner(senderJid, settings)) {
                await sock.sendMessage(from, { text: '❌ هذا الأمر للمالك فقط!' });
                return;
            }

            await sock.sendMessage(from, { text: '🚀 جاري تشغيل البوت...' });
            await startBot(session.currentPhone);
        }
    },
    {
        trigger: 'عرض_اعدادات',
        description: 'عرض الإعدادات الحالية (للمالك)',
        handler: async ({ sock, from, senderJid, settings }) => {
            if (!isOwner(senderJid, settings)) {
                await sock.sendMessage(from, { text: '❌ هذا الأمر للمالك فقط!' });
                return;
            }

            const current = loadSettings();
            const display = [
                `⚙️ *الإعدادات الحالية:*`,
                `• اسم البوت: ${current.botName}`,
                `• البادئة: ${current.commandPrefix || '(بدون)'}`,
                `• رقم المالك: ${current.botOwner || 'غير محدد'}`,
                `• ترحيب: ${current.welcomeEnabled ? '✅' : '❌'}`,
                `• وداع: ${current.goodbyeEnabled ? '✅' : '❌'}`,
                `• حذف الروابط: ${current.autoDeleteLinks ? '✅' : '❌'}`,
                `• مكافحة السبام: ${current.antiSpam ? '✅' : '❌'}`,
                `• الألعاب: ${current.gamesEnabled ? '✅' : '❌'}`,
                `• الموسيقى: ${current.musicEnabled ? '✅' : '❌'}`,
            ].join('\n');
            
            await sock.sendMessage(from, { text: display });
        }
    },
    {
        trigger: 'تحديث_السيرفر',
        description: 'جلب تحديثات من GitHub وإعادة التشغيل (للمالك)',
        handler: async ({ sock, from, senderJid, settings }) => {
            if (!isOwner(senderJid, settings)) {
                await sock.sendMessage(from, { text: '❌ هذا الأمر للمالك فقط!' });
                return;
            }

            await sock.sendMessage(from, { text: '🔄 جاري تحديث السيرفر...' });
            
            exec('git pull && npm install', { cwd: path.join(__dirname, '..') }, async (err, stdout, stderr) => {
                if (err) {
                    await sock.sendMessage(from, { text: `❌ فشل التحديث: ${err.message}` });
                    return;
                }
                await sock.sendMessage(from, { text: `✅ تم التحديث بنجاح!\n${stdout.slice(0, 200)}` });
                
                setTimeout(() => process.exit(0), 2000);
            });
        }
    }
];

module.exports = commands;
logToApp('👑 Owner plugin loaded: تحديث_مالك, تعديل, رفع_وسائط, اعادة, ايقاف_بوت, تشغيل_بوت, عرض_اعدادات, تحديث_السيرفر');