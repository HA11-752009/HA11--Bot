// routes/bot.js — إدارة الجلسات (Multi-Panel)
const express = require('express');
const router  = express.Router();
const stateModule = require('../state');  // ✅ المسار الصحيح (مجلد رئيسي)
const { startBot, stopBot, generatePairingCodeForNumber } = require('../bot');
const { loadSettings, saveSettings } = require('../persistence');
const { formatTime, formatPhone } = require('../utils');

// ── حالة جلسة واحدة ─────────────────────
router.get('/status', (req, res) => {
    const phone = req.query.phone ? formatPhone(req.query.phone) : null;
    const session = phone ? stateModule.getSession(phone) : stateModule.getPrimarySession();

    if (!session) return res.json({ connected: false, status: 'disconnected', phone: phone || '' });

    let status = 'disconnected';
    if (session.isConnected)          status = 'connected';
    else if (session.lastPairingCode) status = 'code_pending';
    else if (session.lastQR)          status = 'qr_pending';

    res.json({
        connected:       session.isConnected,
        phoneNumber:     session.currentPhone,
        name:            session.currentName,
        status,
        uptime:          Math.floor((Date.now() - session.startTime) / 1000),
        messagesHandled: session.messagesHandled
    });
});

// ── حالة كل الجلسات ──────────────────────
router.get('/sessions', (req, res) => {
    const sessions = [];
    for (const [phone, s] of stateModule.sessions) {
        let status = 'disconnected';
        if (s.isConnected)          status = 'connected';
        else if (s.lastPairingCode) status = 'code_pending';
        else if (s.lastQR)          status = 'qr_pending';
        else if (s.isStarting)      status = 'starting';

        sessions.push({
            phone:           phone,
            name:            s.currentName || phone,
            connected:       s.isConnected,
            status,
            uptime:          Math.floor((Date.now() - s.startTime) / 1000),
            messagesHandled: s.messagesHandled,
            lastPairingCode: s.lastPairingCode || null,
        });
    }
    res.json({ sessions, total: sessions.length });
});

// ── تشغيل ─────────────────────────────────
router.post('/connect', (req, res) => {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'رقم الهاتف مطلوب' });
    const cleaned = formatPhone(phone);
    startBot(cleaned).catch(console.error);
    res.json({ status: 'starting', phone: cleaned });
});

// ── إيقاف ─────────────────────────────────
router.post('/disconnect', async (req, res) => {
    const phone = req.body.phone || req.query.phone;
    if (phone) {
        await stopBot(formatPhone(phone));
    } else {
        for (const [p] of stateModule.sessions) {
            await stopBot(p);
        }
    }
    res.json({ success: true });
});

// ── QR Code ───────────────────────────────
router.get('/qr', (req, res) => {
    const phone = req.query.phone;
    const session = phone ? stateModule.getSession(formatPhone(phone)) : stateModule.getPrimarySession();
    if (!session) return res.json({ qrCode: null, status: 'no_session' });
    res.json({
        qrCode:   session.lastQR,
        qrBase64: session.lastQRBase64,
        phone:    session.currentPhone,
        status:   session.isConnected ? 'connected' : (session.lastQR ? 'qr_pending' : 'no_qr')
    });
});

// ── Pairing Code (REST) ───────────────────
router.get('/code', (req, res) => {
    const phone = req.query.phone;
    const session = phone ? stateModule.getSession(formatPhone(phone)) : stateModule.getPrimarySession();
    if (!session) return res.json({ code: null, status: 'no_session' });
    res.json({
        code:   session.lastPairingCode,
        phone:  session.currentPhone,
        status: session.isConnected ? 'connected' : (session.lastPairingCode ? 'code_pending' : 'no_code')
    });
});

// ── استرداد الكود لرقم محدد (نقطة جديدة) ──
router.get('/code/:phone', (req, res) => {
    const phone = formatPhone(req.params.phone);
    const session = stateModule.getSession(phone);
    if (!session) {
        return res.json({ code: null, status: 'no_session', phone });
    }
    res.json({
        code: session.lastPairingCode || null,
        phone: session.currentPhone,
        status: session.isConnected ? 'connected' 
              : (session.lastPairingCode ? 'code_pending' : 'no_code')
    });
});

// ── توليد كود الاقتران ────────────────────
router.post('/generate-code', async (req, res) => {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'رقم الهاتف مطلوب' });
    try {
        const code = await generatePairingCodeForNumber(phone);
        res.json({ code, phone: formatPhone(phone) });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ── تشغيل جلسات محفوظة ───────────────────
router.post('/start-saved', async (req, res) => {
    const s = loadSettings();
    const phones = [s.welcomeNumber, ...(s.extraPhones || [])].filter(Boolean);
    for (const p of phones) {
        startBot(formatPhone(p)).catch(console.error);
    }
    res.json({ started: phones, total: phones.length });
});

module.exports = router;