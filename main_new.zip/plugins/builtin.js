// =============================================
// plugins/builtin.js — الأوامر الأساسية (GIF كفيديو مباشر بالرابط)
// =============================================
const stateModule = require('../state');
const { formatTime, getPhoneFromJid } = require('../utils');
const { loadCommands, loadSettings } = require('../persistence');
const { generatePairingCodeForNumber, startBot, stopBot } = require('../bot');
const { getActivePluginCommands } = require('../handler');

const VIDEO_EXTENSIONS = ['.mp4', '.mov', '.avi', '.mkv', '.webm', '.flv', '.wmv', '.m4v', '.3gp', '.ogv', '.gif'];

function isVideoUrl(url) {
    if (!url) return false;
    const lower = url.toLowerCase();
    return VIDEO_EXTENSIONS.some(ext => lower.endsWith(ext));
}

const commands = [
    {
        trigger: 'ping',
        description: 'اختبار سرعة الاستجابة',
        handler: async ({ sock, from }) => {
            const start = Date.now();
            await sock.sendMessage(from, { text: '🏓 Pong! ...' });
            const ms = Date.now() - start;
            await sock.sendMessage(from, { text: `🏓 *Pong!*\n⚡ الاستجابة: ${ms}ms` });
        }
    },
    {
        trigger: 'صورة',
        description: 'إرسال صورة مع نص',
        handler: async ({ sock, from, args }) => {
            const text = args.join(' ') || 'صورة افتراضية';
            const imageUrl = 'https://example.com/sample.jpg';
            await sock.sendMessage(from, {
                image: { url: imageUrl },
                caption: `🖼️ *${text}*\n\nتم إرسال الصورة بناءً على طلبك.`
            });
        }
    },
    {
        trigger: 'حاله',
        description: 'عرض حالة البوت',
        handler: async ({ sock, from, session }) => {
            const s = session || stateModule.getPrimarySession();
            if (!s) { await sock.sendMessage(from, { text: '❌ لا توجد جلسة نشطة' }); return; }
            const uptime = Math.floor((Date.now() - s.startTime) / 1000);
            const totalSessions = [...stateModule.sessions.values()].filter(x => x.isConnected).length;
            await sock.sendMessage(from, {
                text: [
                    `📊 *حالة البوت*`,
                    `━━━━━━━━━━━━━━`,
                    `✅ متصل: ${s.isConnected ? 'نعم' : 'لا'}`,
                    `📱 رقم: ${s.currentPhone}`,
                    `📨 رسائل تمت معالجتها: ${s.messagesHandled}`,
                    `⏱️ وقت التشغيل: ${formatTime(uptime)}`,
                    `🔗 جلسات نشطة: ${totalSessions}`,
                    `📅 التاريخ: ${new Date().toLocaleDateString('ar-EG')}`,
                ].join('\n')
            });
        }
    },
    {
        trigger: 'اوامر',
        description: 'قائمة الأوامر المتاحة مع صورة/فيديو/GIF',
        handler: async ({ sock, from, settings }) => {
            const prefix = settings.commandPrefix || '';
            const helpImageUrl = settings.helpImageUrl;

            const allPluginCmds = getActivePluginCommands();
            const customCmds = loadCommands().filter(c => c.isEnabled && !c.fromPlugin);

            const helpText = [
                `╔════════════════════╗`,
                `║   ${settings.botName || 'Bot'}  ║`,
                `╚════════════════════╝`,
                ``,
                `🔧 *الأوامر الأساسية:*`,
                allPluginCmds.map(c => `• ${prefix}${c.trigger} — ${c.description}`).join('\n'),
                ``,
                customCmds.length ? `⚙️ *الأوامر المخصصة:*\n${customCmds.map(c => `• ${prefix}${c.trigger}`).join('\n')}` : '',
                ``,
                `💡 *Prefix المستخدم:* "${prefix}"`,
                `📌 *الإصدار:* v3.0 Multi-Panel`,
            ].filter(l => l !== '').join('\n');

            if (helpImageUrl && helpImageUrl.trim() !== '') {
                try {
                    if (isVideoUrl(helpImageUrl)) {
                        const isGif = helpImageUrl.toLowerCase().endsWith('.gif');
                        await sock.sendMessage(from, {
                            video: { url: helpImageUrl },
                            caption: helpText,
                            gifPlayback: isGif
                        });
                    } else {
                        await sock.sendMessage(from, {
                            image: { url: helpImageUrl },
                            caption: helpText
                        });
                    }
                } catch (err) {
                    await sock.sendMessage(from, { text: helpText + '\n\n⚠️ تعذّر تحميل صورة المساعدة.' });
                }
            } else {
                await sock.sendMessage(from, { text: helpText });
            }
        }
    },
    {
        trigger: 'مساعدة',
        description: 'إرسال صورة/فيديو/GIF المساعدة',
        handler: async ({ sock, from, settings }) => {
            const helpImageUrl = settings.helpImageUrl;
            if (!helpImageUrl) {
                await sock.sendMessage(from, { text: '❌ لم يتم تعيين صورة المساعدة بعد.' });
                return;
            }
            try {
                if (isVideoUrl(helpImageUrl)) {
                    const isGif = helpImageUrl.toLowerCase().endsWith('.gif');
                    await sock.sendMessage(from, {
                        video: { url: helpImageUrl },
                        caption: `📸 *صورة المساعدة*\nاستخدم ${settings.commandPrefix || '!'}اوامر لعرض قائمة الأوامر.`,
                        gifPlayback: isGif
                    });
                } else {
                    await sock.sendMessage(from, {
                        image: { url: helpImageUrl },
                        caption: `📸 *صورة المساعدة*\nاستخدم ${settings.commandPrefix || '!'}اوامر لعرض قائمة الأوامر.`
                    });
                }
            } catch (err) {
                await sock.sendMessage(from, { text: `❌ تعذّر تحميل صورة المساعدة من الرابط:\n${helpImageUrl}` });
            }
        }
    },
    {
        trigger: 'جلسات',
        description: 'عرض كل الجلسات النشطة',
        handler: async ({ sock, from }) => {
            const all = [];
            for (const [phone, s] of stateModule.sessions) {
                all.push(`• ${phone}: ${s.isConnected ? '✅ متصل' : '🔴 منقطع'} — ${s.currentName || phone}`);
            }
            await sock.sendMessage(from, {
                text: [
                    `📱 *الجلسات النشطة (${stateModule.sessions.size}):*`,
                    all.length ? all.join('\n') : '• لا توجد جلسات',
                ].join('\n')
            });
        }
    },
    {
        trigger: 'تنصيب',
        description: 'ربط رقم جديد بالبوت',
        handler: async ({ sock, from, args, settings }) => {
            const prefix = settings.commandPrefix || '';
            let targetPhone = args[0];
            if (!targetPhone) {
                await sock.sendMessage(from, { text: `❌ استخدام: ${prefix}تنصيب 20xxxxxxxxxx` });
                return;
            }
            targetPhone = targetPhone.replace(/\D/g, '');
            if (targetPhone.length < 10) {
                await sock.sendMessage(from, { text: `❌ رقم غير صالح` }); return;
            }
            try {
                const existing = stateModule.getSession(targetPhone);
                if (existing?.isConnected) {
                    await sock.sendMessage(from, { text: `⚠️ الرقم ${targetPhone} متصل بالفعل` });
                    return;
                }
                await sock.sendMessage(from, { text: `🔄 جاري تجهيز كود الاقتران...` });
                const code = await generatePairingCodeForNumber(targetPhone);
                await sock.sendMessage(from, {
                    text: [
                        `🔑 *كود الاقتران للرقم ${targetPhone}*`,
                        ``,
                        `\`\`\`${code}\`\`\``,
                        ``,
                        `📱 *خطوات الربط:*`,
                        `1. افتح واتساب`,
                        `2. الأجهزة المرتبطة ← ربط بالرمز`,
                        `3. أدخل الكود: *${code}*`,
                        ``,
                        `✨ سيبدأ البوت تلقائياً بعد الاقتران.`
                    ].join('\n')
                });
            } catch (err) {
                await sock.sendMessage(from, { text: `❌ فشل: ${err.message}` });
            }
        }
    },
    {
        trigger: 'ايقاف',
        description: 'إيقاف جلسة رقم معين',
        handler: async ({ sock, from, args }) => {
            const targetPhone = args[0]?.replace(/\D/g, '');
            if (!targetPhone) {
                await sock.sendMessage(from, { text: '❌ استخدام: !ايقاف 20xxxxxxxxxx' }); return;
            }
            const s = stateModule.getSession(targetPhone);
            if (!s) { await sock.sendMessage(from, { text: `❌ لا توجد جلسة للرقم ${targetPhone}` }); return; }
            await stopBot(targetPhone);
            await sock.sendMessage(from, { text: `✅ تم إيقاف الرقم ${targetPhone}` });
        }
    },
    {
        trigger: 'منشن',
        description: 'منشن الكل في المجموعة',
        groupOnly: true,
        adminOnly: true,
        handler: async ({ sock, from, fullText, settings }) => {
            const prefix = settings.commandPrefix || '';
            const meta = await sock.groupMetadata(from);
            const mentions = meta.participants.map(p => p.id);
            const extra = fullText.replace(`${prefix}منشن`, '').trim();
            const msgText = `${extra || '👋 تنبيه للجميع!'}\n\n` +
                mentions.map(m => `@${m.split('@')[0]}`).join(' ');
            await sock.sendMessage(from, { text: msgText, mentions });
        }
    },
    {
        trigger: 'عدد',
        description: 'عدد أعضاء المجموعة',
        groupOnly: true,
        handler: async ({ sock, from }) => {
            const meta = await sock.groupMetadata(from);
            const admins = meta.participants.filter(p => p.admin);
            await sock.sendMessage(from, {
                text: [
                    `👥 *إحصائيات المجموعة*`,
                    `━━━━━━━━━━━━━━`,
                    `📛 الاسم: ${meta.subject}`,
                    `👤 الأعضاء: ${meta.participants.length}`,
                    `👑 المشرفون: ${admins.length}`,
                    `🧑 الأعضاء العاديون: ${meta.participants.length - admins.length}`,
                ].join('\n')
            });
        }
    },
    {
        trigger: 'تاج',
        description: 'منشن عضو معين',
        groupOnly: true,
        handler: async ({ sock, from, args, msg }) => {
            const ctxInfo = msg.message?.extendedTextMessage?.contextInfo;
            const targetJid = ctxInfo?.participant || (args[0] ? `${args[0].replace(/\D/g, '')}@s.whatsapp.net` : null);
            if (!targetJid) { await sock.sendMessage(from, { text: '⚠️ اقتبس رسالة العضو أو اكتب الرقم' }); return; }
            await sock.sendMessage(from, { text: `🏷️ @${targetJid.split('@')[0]}`, mentions: [targetJid] });
        }
    },
    {
        trigger: 'وقت',
        description: 'عرض الوقت والتاريخ',
        handler: async ({ sock, from }) => {
            const now = new Date();
            await sock.sendMessage(from, {
                text: [
                    `🕐 *الوقت والتاريخ*`,
                    `📅 ${now.toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`,
                    `⏰ ${now.toLocaleTimeString('ar-EG')}`,
                ].join('\n')
            });
        }
    },
];

module.exports = commands;