// =============================================
// plugins/fun.js — أوامر مضحكة وترفيهية
// =============================================

// ── قائمة النكت ──────────────────────────
const jokes = [
    'لماذا لا يجوع الكمبيوتر؟ لأنه دايماً بياكل chips! 💻😂',
    'دكتور: جيب لسانك!\nالمريض: مش ممكن، أنا مش ببرمجه! 😅',
    'قلت لصاحبي: أنا باتعلم برمجة\nقالي: والله؟ بقى انت بتتكلم لغات! 😂',
    'رجل دخل المستشفى قال: عندي ألف وجع\nالدكتور قاله: Overflow! 🔢',
    'الأم: ليه مش نمت؟\nالابن: في bug في الكود\nالأم: بكره تحله\nالابن: مش ممكن ينام مع bug في production! 😭',
    'سؤال: ايه أكبر كذبة في الدنيا؟\nجواب: "I have read and agree to the Terms and Conditions" 😂',
    'سؤال: ليه البرمجرز بيحبوا الظلام؟\nجواب: لأن Light attracts bugs! 🐛',
    'قلت لصديقي: كود باعتله بـ 1000 سطر\nقالي: والله؟ ده كويس!\nقلتله: آه بس كلها print("Hello") 😂',
    '404: النكتة مش موجودة 😂',
    'الواحد لو بكى وحيد يبكي\nالواحد لو بكى مع برمجرز قالوله: "Handle the exception!" 💻😢',
    'ليه المبرمج مش بيتجوز؟\nلأنه بيدور على Miss Perfect وهي مش موجودة! 😅',
    'أنا مش كسلان، أنا في Standby Mode! 🔋',
    'حياة المبرمج:\nيصحى → شغل كمبيوتر → copy paste → نوم 😴',
    'Ctrl+Z لو شتغل في الحياة الحقيقية كان حياتنا تبقى أحسن بكتير 😂',
    'أنا مش بتأخر، أنا في Loading Mode ⌛',
];

// ── اقتباسات ─────────────────────────────
const quotes = [
    '"النجاح ليس نهائياً، والفشل ليس قاتلاً، الشجاعة هي ما يهم." — تشرشل',
    '"الفرق بين المستحيل والممكن يكمن في عزيمة الإنسان." — تومي لاسورتا',
    '"اسعَ للنجاح لا لتأثر الآخرين به." — مجهول',
    '"كل يوم هو فرصة جديدة لتغيير حياتك." — مجهول',
    '"العقل هو كل شيء. أنت ما تفكر فيه." — بوذا',
    '"الطريق الوحيد للقيام بعمل رائع هو حب ما تفعله." — ستيف جوبز',
    '"لا تنتظر الفرصة، بل اصنعها." — مجهول',
    '"الأخطاء دروس غالية الثمن." — مجهول',
    '"التغيير صعب في البداية، ومؤلم في المنتصف، ورائع في النهاية." — روبن شارما',
];

// ── حظ اليوم ──────────────────────────────
const fortunes = [
    '⭐ حظك اليوم ممتاز! احتمال كبير إنك تلاقي مفتاح ضيعته من سنة! 😄',
    '🌟 اليوم يوم جميل! بس خليك بعيد عن المطبخ! 🔥',
    '💫 حظك في الكلام أحسن من حظك في البرمجة! 😅',
    '✨ اليوم هتقابل شخص غريب... ابص في المرايا! 😂',
    '🌈 حظك كويس بس بشرط متفتحش تويتر النهارده! 😅',
    '⚡ تحذير: يوم صعب! الحل: شاي + شوكولاتة + إيقاف الموبايل! ☕',
    '🎯 النجوم تقول إنك هتنجح... بعد ما توقف سكرول الموبايل! 📱',
    '🍀 رقمك المحظوظ اليوم: 42! (الإجابة عن كل شيء!) 😄',
];

// ── الرد على أسئلة الكرة ──────────────────
const ball8Responses = [
    '✅ نعم، بكل تأكيد!',
    '❓ من المرجح ذلك',
    '🌟 الإشارات تشير إلى نعم',
    '🔮 بالتأكيد!',
    '😊 المستقبل يبدو مشجعاً',
    '❌ لا أعتقد ذلك',
    '😟 الإجابة لا',
    '🌫️ غير واضح... اسأل لاحقاً',
    '🤷 الأمور ضبابية',
    '⚠️ من الأفضل الانتظار',
    '🎱 ركز وأعد السؤال',
    '💭 لا يمكن التنبؤ الآن',
];

function getRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

module.exports = [
    {
        trigger: 'نكتة',
        description: 'يقول نكتة مضحكة 😂',
        handler: async ({ sock, from }) => {
            await sock.sendMessage(from, { text: getRandom(jokes) });
        }
    },
    {
        trigger: 'اقتباس',
        description: 'اقتباس مُلهم 🌟',
        handler: async ({ sock, from }) => {
            await sock.sendMessage(from, { text: `💬 ${getRandom(quotes)}` });
        }
    },
    {
        trigger: 'حظي',
        description: 'حظك اليوم 🔮',
        handler: async ({ sock, from, senderJid }) => {
            const name = senderJid?.split('@')[0];
            await sock.sendMessage(from, {
                text: `🔮 *حظ ${name} اليوم:*\n\n${getRandom(fortunes)}`
            });
        }
    },
    {
        trigger: 'كرة',
        description: 'سؤال على كرة المجيب 🎱',
        handler: async ({ sock, from, args }) => {
            const question = args.join(' ').trim();
            if (!question) {
                await sock.sendMessage(from, { text: '🎱 اكتب سؤالك بعد الأمر!\nمثال: `!كرة هيجي المشوار؟`' });
                return;
            }
            await sock.sendMessage(from, { text: `🎱 *سؤالك:* ${question}\n\n*الإجابة:* ${getRandom(ball8Responses)}` });
        }
    },
    {
        trigger: 'زهر',
        description: 'رمي زهر النرد 🎲',
        handler: async ({ sock, from }) => {
            const dice = Math.floor(Math.random() * 6) + 1;
            const faces = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣'];
            await sock.sendMessage(from, { text: `🎲 رميت الزهر!\n\nالنتيجة: ${faces[dice - 1]} (${dice})` });
        }
    },
    {
        trigger: 'عملة',
        description: 'رمي عملة 🪙',
        handler: async ({ sock, from }) => {
            const result = Math.random() < 0.5 ? '👑 صورة' : '📜 كتابة';
            await sock.sendMessage(from, { text: `🪙 رميت العملة...\n\nالنتيجة: *${result}*!` });
        }
    },
    {
        trigger: 'اختار',
        description: 'اختيار عشوائي بين خيارات',
        handler: async ({ sock, from, args }) => {
            if (args.length < 2) {
                await sock.sendMessage(from, { text: '❌ استخدام: !اختار خيار1 خيار2 خيار3' });
                return;
            }
            const choice = getRandom(args);
            await sock.sendMessage(from, { text: `🎯 *اخترت لك:*\n\n➤ *${choice}*` });
        }
    },
    {
        trigger: 'ذكاء',
        description: 'قياس نسبة الذكاء 😄',
        handler: async ({ sock, from, senderJid }) => {
            const iq = Math.floor(Math.random() * 200) + 1;
            const msgs = [
                [180, '🧠 عبقري خارق! كتب بدك الـ AI مكانك؟'],
                [150, '🎓 ذكاء استثنائي! واضح التعليم بيعدي!'],
                [120, '✨ ذكاء فوق المتوسط — شاطر!'],
                [100, '😊 ذكاء طبيعي — ماشي الحال!'],
                [80, '🙈 يمكن تراجعت اليومين دول؟'],
                [60, '😂 ماتفكرش كتير، الدماغ بتتعب!'],
                [0, '🤖 الـ AI أذكى منك بكتير! 😆'],
            ];
            const comment = msgs.find(([min]) => iq >= min)?.[1] || msgs[msgs.length - 1][1];
            await sock.sendMessage(from, {
                text: `🧠 *قياس الذكاء*\n\nالنتيجة: *${iq} IQ*\n${comment}`
            });
        }
    },
    {
        trigger: 'احجار',
        description: 'لعبة الحجر والورقة والمقص ✂️',
        handler: async ({ sock, from, args }) => {
            const choices = { 'حجر': '🪨', 'ورقة': '📄', 'مقص': '✂️' };
            const userChoice = args[0];
            if (!userChoice || !choices[userChoice]) {
                await sock.sendMessage(from, { text: '❌ استخدام: !احجار حجر\nالخيارات: حجر | ورقة | مقص' });
                return;
            }
            const botKeys  = Object.keys(choices);
            const botChoice = getRandom(botKeys);
            const userEmoji = choices[userChoice];
            const botEmoji  = choices[botChoice];

            let result;
            if (userChoice === botChoice) result = '🤝 تعادل!';
            else if (
                (userChoice === 'حجر'  && botChoice === 'مقص')  ||
                (userChoice === 'مقص'  && botChoice === 'ورقة') ||
                (userChoice === 'ورقة' && botChoice === 'حجر')
            ) result = '🎉 انت كسبت!';
            else result = '😅 البوت كسب!';

            await sock.sendMessage(from, {
                text: [
                    `✂️🪨📄 *الحجر والورقة والمقص*`,
                    ``,
                    `انت: ${userEmoji} ${userChoice}`,
                    `البوت: ${botEmoji} ${botChoice}`,
                    ``,
                    `🏆 ${result}`,
                ].join('\n')
            });
        }
    },
    {
        trigger: 'طالع',
        description: 'يطلع رقم عشوائي 🎰',
        handler: async ({ sock, from, args }) => {
            const max = parseInt(args[0]) || 100;
            const num = Math.floor(Math.random() * max) + 1;
            await sock.sendMessage(from, { text: `🎰 الرقم العشوائي من 1 إلى ${max}:\n\n*${num}*` });
        }
    },
    {
        trigger: 'شخصية',
        description: 'تحليل شخصيتك 🔮',
        handler: async ({ sock, from, senderJid }) => {
            const personalities = [
                '🦁 أنت شخص قوي وقيادي! الناس بتتبعك تلقائياً',
                '🦊 أنت ذكي ومتحيل! دايماً بتلاقي حل لأي مشكلة',
                '🐺 أنت تعمل بشكل أفضل مع الفريق ولكنك مستقل',
                '🦅 أنت طموح وبتشوف الصورة الكبيرة دايماً',
                '🦋 أنت شخص مبدع وبتحب التغيير',
                '🐬 أنت ودود ومحبوب من الجميع',
                '🦉 أنت حكيم وبتفكر قبل ما تتكلم',
                '🐉 أنت نادر وعندك مواهب خاصة!',
            ];
            await sock.sendMessage(from, {
                text: `🔮 *تحليل شخصيتك:*\n\n${getRandom(personalities)}`
            });
        }
    },
];
