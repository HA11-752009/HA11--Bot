// ws.js — WebSocket Server (Multi-Panel Support)
const { WebSocketServer } = require('ws');
const stateModule = require('./state');

let currentWss = null;
const clients = new Set();

function buildSessionList() {
    const list = [];
    for (const [phone, s] of stateModule.sessions) {
        list.push({
            phone,
            connected: s.isConnected,
            name: s.currentName || phone,
            lastPairingCode: s.lastPairingCode || null,
            status: s.isConnected ? 'connected'
                  : s.lastPairingCode ? 'code_pending'
                  : s.lastQR ? 'qr_pending'
                  : s.isStarting ? 'starting'
                  : 'disconnected'
        });
    }
    return list;
}

function broadcast(message) {
    clients.forEach(client => { if (client.readyState === 1) client.send(message); });
}

function logToApp(message, phone = null) {
    const timestamp = new Date().toLocaleTimeString('ar-EG');
    const prefix = phone ? `[${phone}] ` : '';
    const logLine = `[${timestamp}] ${prefix}${message}`;
    console.log(logLine);
    broadcast(logLine);
}

function broadcastSessionUpdate() {
    broadcast(`SESSIONS:${JSON.stringify(buildSessionList())}`);
}

function broadcastCode(phone, code) {
    broadcast(`CODE:${phone}:${code}`);
    broadcastSessionUpdate();
}

function broadcastTaskLog(taskId, type, data) {
    const msg = `TASK_LOG:${taskId}:${type}:${data}`;
    clients.forEach(client => { if (client.readyState === 1) client.send(msg); });
}

function startWebSocketServer(port) {
    if (currentWss) { try { currentWss.close(); } catch {} }
    currentWss = new WebSocketServer({ port });
    console.log(`[WS] WebSocket server started on port ${port}`);

    currentWss.on('connection', (ws) => {
        clients.add(ws);
        console.log('[WS] Client connected');

        const allSessions = buildSessionList();
        if (allSessions.length) ws.send(`SESSIONS:${JSON.stringify(allSessions)}`);

        for (const [phone, s] of stateModule.sessions) {
            if (s.lastPairingCode && !s.isConnected) ws.send(`CODE:${phone}:${s.lastPairingCode}`);
            if (s.lastQRBase64 && !s.isConnected) ws.send(`QR:${phone}:${s.lastQRBase64}`);
        }

        ws.on('message', (rawMessage) => {
            const msg = rawMessage.toString();
            if (msg.startsWith('REQUEST_CODE:')) {
                const phone = msg.split(':')[1];
                const session = stateModule.getSession(phone);
                if (session && session.lastPairingCode && !session.isConnected) {
                    ws.send(`CODE:${phone}:${session.lastPairingCode}`);
                } else {
                    ws.send(`CODE_ERROR:${phone}:no_code`);
                }
            }
        });

        ws.on('close', () => clients.delete(ws));
    });
}

module.exports = {
    startWebSocketServer,
    broadcast,
    logToApp,
    broadcastSessionUpdate,
    broadcastCode,
    broadcastTaskLog
};