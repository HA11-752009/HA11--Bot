// =============================================
// plugins/fun.js — أوامر ترفيهية ذكية (Groq Llama 3.1)
// =============================================
const { loadSettings } = require('../persistence');
const { logToApp } = require('../ws');

// ⚠️ ضع مفتاح Groq API المجاني هنا (أو اتركه فارغاً واستخدم settings.json)
const HARDCODED_GROQ_KEY = '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'; // مثال: 'gsk_...'

function getApiKey() {
    const settings = loadSettings();
    return settings.groqKey || HARDCODED_GROQ_KEY || null;
}

/**
 * استدعاء Groq Cloud – Llama 3.1 8B (مجاني حتى حد معين يومياً)
 */
async function callGroqAI(prompt) {
    const apiKey = getApiKey();
    if (!apiKey) return null;

    try {
        const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: 'llama-3.1-8b-instant',
                messages: [
                    { role: 'system', content: 'أجب بالعربية فقط، باختصار وإبداع.' },
                    { role: 'user', content: prompt }
                ],
                max_tokens: 100,
                temperature: 1.2
            }),
            timeout: 15000
        });

        const data = await response.json();
        if (data.choices && data.choices.length > 0) {
            logToApp('✅ Groq استجاب بنجاح');
            return data.choices[0].message.content.trim();
        } else if (data.error) {
            logToApp('❌ Groq: ' + data.error.message);
        }
    } catch (err) {
        logToApp('❌ Groq فشل: ' + (err.message || err));
    }
    return null;
}

/** إزالة أي روابط قد تتسرب */
function removeAnyLinks(text) {
    return text.replace(/(https?:\/\/[^\s]+)/g, '[🔗]').trim();
}

/**
 * الحصول على رد الذكاء أو الاحتياطي
 */
async function getAIResponse(prompt, fallback) {
    const aiReply = await callGroqAI(prompt);
    if (aiReply) return removeAnyLinks(aiReply);
    // فقط لو فشل الاتصال أو لم يوجد مفتاح، استخدم الاحتياطي
    return fallback[Math.floor(Math.random() * fallback.length)];
}

// ── مصفوفات احتياطية ضخمة ─────────────────
const jokesFB = [
    'لماذا لا يجوع الكمبيوتر؟ لأنه دايماً بياكل chips! 💻😂',
    'دكتور: جيب لسانك!\nالمريض: مش ممكن، أنا مش ببرمجه! 😅',
    'قلت لصاحبي: أنا باتعلم برمجة\nقالي: والله؟ بقى انت بتتكلم لغات! 😂',
    'رجل دخل المستشفى قال: عندي ألف وجع\nالدكتور قاله: Overflow! 🔢',
    'الأم: ليه مش نمت؟\nالابن: في bug في الكود\nالأم: بكره تحله\nالابن: مش ممكن ينام مع bug في production! 😭',
    'سؤال: ايه أكبر كذبة في الدنيا؟\nجواب: "I have read and agree to the Terms and Conditions" 😂',
    'سؤال: ليه البرمجرز بيحبوا الظلام؟\nجواب: لأن Light attracts bugs! 🐛',
    'قلت لصديقي: كود باعتله بـ 1000 سطر\nقالي: والله؟ ده كويس!\nقلتله: آه بس كلها print("Hello") 😂',
    '404: النكتة مش موجودة 😂',
    'الواحد لو بكى وحيد يبكي\nالواحد لو بكى مع برمجرز قالوله: "Handle the exception!" 💻😢',
    'ليه المبرمج مش بيتجوز؟\nلأنه بيدور على Miss Perfect وهي مش موجودة! 😅',
    'أنا مش كسلان، أنا في Standby Mode! 🔋',
    'حياة المبرمج:\nيصحى → شغل كمبيوتر → copy paste → نوم 😴',
    'Ctrl+Z لو اشتغل في الحياة الحقيقية كان حياتنا تبقى أحسن بكتير 😂',
    'أنا مش بتأخر، أنا في Loading Mode ⌛',
    'الفيسبوك: أنا اجتماعي\nتويتر: أنا سريع\nجوجل: أنا اللي عارف كل حاجة\nالواتساب: أنا اللي موصل الكل',
    'الأب: ابنك ده هيبقى دكتور\nالأم: لأ هيبقى مهندس\nالطفل: لأ أنا هبقى Bug في الكود',
    'ليه القهوة مش بتلعب لعبة؟\nعلشان بتخاف تتحمص! ☕😂',
    'واحد قال لصاحبه: أنا خسرت كل حاجة\nقاله: طب جربت تعمل Undo?',
    'ليه الثلاجة مش بتنام؟\nعلشان طول الليل بتطن! 🧊',
];

const quotesFB = [
    '"النجاح ليس نهائياً، والفشل ليس قاتلاً، الشجاعة هي ما يهم." — تشرشل',
    '"الفرق بين المستحيل والممكن يكمن في عزيمة الإنسان." — تومي لاسورتا',
    '"اسعَ للنجاح لا لتأثر الآخرين به." — مجهول',
    '"كل يوم هو فرصة جديدة لتغيير حياتك." — مجهول',
    '"العقل هو كل شيء. أنت ما تفكر فيه." — بوذا',
    '"الطريق الوحيد للقيام بعمل رائع هو حب ما تفعله." — ستيف جوبز',
    '"لا تنتظر الفرصة، بل اصنعها." — مجهول',
    '"الأخطاء دروس غالية الثمن." — مجهول',
    '"التغيير صعب في البداية، ومؤلم في المنتصف، ورائع في النهاية." — روبن شارما',
    '"الحياة إما مغامرة جريئة أو لا شيء." — هيلين كيلر',
    '"كن أنت التغيير الذي تريد أن تراه في العالم." — المهاتما غاندي',
    '"في قلب كل صعوبة تكمن فرصة." — ألبرت أينشتاين',
    '"العلم بدون دين أعرج، والدين بدون علم أعمى." — أينشتاين',
    '"أفضل وقت لزرع شجرة كان قبل 20 عاماً، وثاني أفضل وقت هو الآن." — مثل صيني',
    '"لا يستطيع أحد أن يركب ظهرك إلا إذا كنت منحنياً." — مارتن لوثر كينغ',
    '"الضعيف لا يغفر، التسامح من صفات القوي." — غاندي',
    '"النجاح هو الانتقال من فشل إلى فشل دون أن تفقد حماسك." — تشرشل',
    '"الأفكار العظيمة لا تحتاج إلى أجنحة، بل إلى عجلات." — مجهول',
    '"تعلم من الأمس، عش اليوم، أمل في الغد." — أينشتاين',
    '"البساطة هي أقصى درجات التعقيد." — ليوناردو دافنشي',
];

const fortunesFB = [
    '⭐ حظك اليوم ممتاز! احتمال كبير إنك تلاقي مفتاح ضيعته من سنة!',
    '🌟 اليوم يوم جميل! بس خليك بعيد عن المطبخ!',
    '💫 حظك في الكلام أحسن من حظك في البرمجة!',
    '✨ اليوم هتقابل شخص غريب... ابص في المرايا!',
    '🌈 حظك كويس بس بشرط متفتحش تويتر النهارده!',
    '⚡ تحذير: يوم صعب! الحل: شاي + شوكولاتة + إيقاف الموبايل!',
    '🎯 النجوم تقول إنك هتنجح... بعد ما توقف سكرول الموبايل!',
    '🍀 رقمك المحظوظ اليوم: 42! (الإجابة عن كل شيء!)',
    '🎭 حظك اليوم غامض... حتى النجوم مش عارفة!',
    '🎪 اليوم فيه مفاجأة كبيرة، استعد!',
    '🛸 طبق فضائي هيهبط جنبك... ممكن تسأله عن أرقام اليانصيب',
    '🎲 الحظ بيرقص النهارده، خليك مع الإيقاع',
    '🔮 الرؤية مش واضحة، لكنها مبشرة',
    '🎈 يومك مليان ألوان وفرح، استمتع',
    '🍕 البيتزا بتاعتك هتكون مضبوطة النهارده',
    '📚 يوم مناسب للقراءة أو التعلم',
    '🎧 ألبس السماعات واسمع أغنيتك المفضلة',
    '🏃‍♂️ الرياضة هتنفعك اليوم جداً',
    '💡 فكرة عبقرية هتيجي في بالك النهارده بالليل',
    '🌙 الليل هيكون هادي وجميل',
];

const personalitiesFB = [
    '🦁 أنت شخص قوي وقيادي! الناس بتتبعك تلقائياً',
    '🦊 أنت ذكي ومتحيل! دايماً بتلاقي حل لأي مشكلة',
    '🐺 أنت تعمل بشكل أفضل مع الفريق ولكنك مستقل',
    '🦅 أنت طموح وبتشوف الصورة الكبيرة دايماً',
    '🦋 أنت شخص مبدع وبتحب التغيير',
    '🐬 أنت ودود ومحبوب من الجميع',
    '🦉 أنت حكيم وبتفكر قبل ما تتكلم',
    '🐉 أنت نادر وعندك مواهب خاصة!',
    '🐱 أنت غامض وجذاب، تحب استكشاف المجهول',
    '🐶 أنت مخلص ووفيّ لأصدقائك وعائلتك',
    '🐴 أنت نشيط ومليء بالحيوية، تحب الحركة',
    '🦢 أنت راقي وأنيق في تصرفاتك',
    '🐘 أنت صبور وقوي، تتحمل الصعاب',
    '🦚 أنت واثق من نفسك وتحب جذب الانتباه',
    '🐻 أنت دافئ وحنون، تلجأ إليك الناس للراحة',
    '🦜 أنت اجتماعي وتحب التواصل والضحك',
    '🐢 أنت هادئ وتخطط جيداً قبل أي خطوة',
    '🐬 أنت ذكي ومرح، وتحب مساعدة الآخرين',
    '🦩 أنت مميز وفريد بأسلوبك الخاص',
    '🐳 أنت كبير في حلمك وطموحاتك',
];

function rnd(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

// ============== الأوامر ==============
module.exports = [
    {
        trigger: 'نكتة',
        description: 'نكتة مضحكة 😂',
        handler: async ({ sock, from }) => {
            const reply = await getAIResponse('قل نكتة قصيرة ومضحكة بالعامية المصرية.', jokesFB);
            await sock.sendMessage(from, { text: `😂 ${reply}` });
        }
    },
    {
        trigger: 'اقتباس',
        description: 'اقتباس مُلهم 🌟',
        handler: async ({ sock, from }) => {
            const reply = await getAIResponse('أعطني اقتباساً ملهماً بالعربية مع اسم القائل.', quotesFB);
            await sock.sendMessage(from, { text: `💬 ${reply}` });
        }
    },
    {
        trigger: 'حظي',
        description: 'حظك اليوم 🔮',
        handler: async ({ sock, from, senderJid }) => {
            const name = senderJid?.split('@')[0] || 'المستخدم';
            const reply = await getAIResponse(`توقع حظ "${name}" اليوم بفكاهة.`, fortunesFB);
            await sock.sendMessage(from, { text: `🔮 *حظ ${name} اليوم:*\n\n${reply}` });
        }
    },
    {
        trigger: 'كرة',
        description: 'سؤال كرة 8-ball الذكية 🎱',
        handler: async ({ sock, from, args }) => {
            const q = args.join(' ').trim();
            if (!q) { await sock.sendMessage(from, { text: '🎱 اكتب سؤالك بعد الأمر!' }); return; }
            const reply = await getAIResponse(
                `أجب ككرة 8-ball بجملة قصيرة على: "${q}"`,
                ['بالتأكيد','لا أعتقد','ربما','غير واضح','نعم']
            );
            await sock.sendMessage(from, { text: `🎱 *سؤالك:* ${q}\n\n*الإجابة:* ${reply}` });
        }
    },
    {
        trigger: 'زهر',
        description: 'رمي زهر النرد 🎲',
        handler: async ({ sock, from }) => {
            const dice = Math.floor(Math.random() * 6) + 1;
            const faces = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣'];
            await sock.sendMessage(from, { text: `🎲 ${faces[dice-1]} (${dice})` });
        }
    },
    {
        trigger: 'عملة',
        description: 'رمي عملة 🪙',
        handler: async ({ sock, from }) => {
            const res = Math.random() < 0.5 ? '👑 صورة' : '📜 كتابة';
            await sock.sendMessage(from, { text: `🪙 ${res}` });
        }
    },
    {
        trigger: 'اختار',
        description: 'اختيار عشوائي بين خيارات',
        handler: async ({ sock, from, args }) => {
            if (args.length < 2) { await sock.sendMessage(from, { text: '❌ استخدم: !اختار خيار1 خيار2 ...' }); return; }
            await sock.sendMessage(from, { text: `🎯 *اخترت:* ${rnd(args)}` });
        }
    },
    {
        trigger: 'ذكاء',
        description: 'قياس نسبة الذكاء 😄',
        handler: async ({ sock, from }) => {
            const iq = Math.floor(Math.random() * 200) + 1;
            const msgs = [[180,'🧠 عبقري!'],[150,'🎓 ذكي جداً'],[120,'✨ فوق المتوسط'],[100,'😊 طبيعي'],[80,'🙈 ركز شوية'],[60,'😂 مش أحسن حاجة'],[0,'🤖 AI أذكى']];
            const comment = msgs.find(([m]) => iq >= m)?.[1] || msgs[0][1];
            await sock.sendMessage(from, { text: `🧠 *${iq} IQ*\n${comment}` });
        }
    },
    {
        trigger: 'طالع',
        description: 'رقم عشوائي 🎰',
        handler: async ({ sock, from, args }) => {
            const max = parseInt(args[0]) || 100;
            const num = Math.floor(Math.random() * max) + 1;
            await sock.sendMessage(from, { text: `🎰 1-${max}: *${num}*` });
        }
    },
    {
        trigger: 'شخصية',
        description: 'تحليل شخصيتك 🔮',
        handler: async ({ sock, from, senderJid }) => {
            const name = senderJid?.split('@')[0] || 'أنت';
            const reply = await getAIResponse(`حلل شخصية "${name}" بثلاث صفات إيجابية مع رموز تعبيرية.`, personalitiesFB);
            await sock.sendMessage(from, { text: `🔮 *تحليل ${name}:*\n\n${reply}` });
        }
    },
    {
        trigger: 'اصفر',
        description: 'نكتة عن اللون الأصفر 😂',
        handler: async ({ sock, from }) => {
            const reply = await getAIResponse('نكتة قصيرة بالعامية عن اللون الأصفر.', [
                'ليه الأصفر بيعيط؟ علشان الليمون ضربه! 🍋😂',
                'مرة واحد أصفر راح للدكتور قاله: عندي صفار! الدكتور قاله: ده طبيعي يا ليمون! 😅'
            ]);
            await sock.sendMessage(from, { text: `🟡 ${reply}` });
        }
    },
];