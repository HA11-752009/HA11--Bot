// routes/settings.js — كل الإعدادات + تحديث السيرفر مع نسخ احتياطي
const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const AdmZip = require('adm-zip');
const stateModule = require('../state');
const { loadSettings, saveSettings } = require('../persistence');
const { startBot, stopBot } = require('../bot');
const { formatPhone } = require('../utils');
const { logToApp } = require('../ws');

// ── الحصول على جميع الإعدادات ─────────────────
router.get('/', (req, res) => {
    res.json(loadSettings());
});

// ── تحديث الإعدادات ─────────────────────────
router.put('/', (req, res) => {
    const merged = saveSettings(req.body);
    for (const [, s] of stateModule.sessions) {
        s.currentName = merged.botName;
    }
    res.json({ success: true, settings: merged });
});

// ── إضافة رقم إضافي (وتشغيله تلقائياً) ───────
router.post('/add-phone', async (req, res) => {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'رقم مطلوب' });
    const s = loadSettings();
    if (!s.extraPhones) s.extraPhones = [];
    const cleaned = formatPhone(phone);
    if (!cleaned) return res.status(400).json({ error: 'رقم غير صالح' });
    
    if (cleaned === s.welcomeNumber) {
        return res.status(409).json({ error: 'الرقم موجود بالفعل كرقم رئيسي' });
    }
    if (s.extraPhones.includes(cleaned)) {
        return res.status(409).json({ error: 'الرقم موجود بالفعل في القائمة' });
    }
    
    s.extraPhones.push(cleaned);
    saveSettings(s);
    
    try {
        await startBot(cleaned);
    } catch (err) {
        console.error(`فشل تشغيل الرقم ${cleaned}:`, err);
    }
    
    res.json({ success: true, extraPhones: s.extraPhones });
});

// ── حذف رقم إضافي (وإيقافه تلقائياً) ─────────
router.delete('/remove-phone', async (req, res) => {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'رقم مطلوب' });
    const s = loadSettings();
    const cleaned = formatPhone(phone);
    if (!cleaned) return res.status(400).json({ error: 'رقم غير صالح' });
    
    if (!s.extraPhones || !s.extraPhones.includes(cleaned)) {
        return res.status(404).json({ error: 'الرقم غير موجود في القائمة' });
    }
    
    s.extraPhones = s.extraPhones.filter(p => p !== cleaned);
    saveSettings(s);
    
    try {
        await stopBot(cleaned);
    } catch (err) {
        console.error(`فشل إيقاف الرقم ${cleaned}:`, err);
    }
    
    res.json({ success: true, extraPhones: s.extraPhones });
});

// ── تعيين رقم رئيسي (وتشغيله) ────────────────
router.post('/set-primary', async (req, res) => {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'رقم مطلوب' });
    const cleaned = formatPhone(phone);
    if (!cleaned) return res.status(400).json({ error: 'رقم غير صالح' });
    
    const s = loadSettings();
    s.welcomeNumber = cleaned;
    if (s.extraPhones && s.extraPhones.includes(cleaned)) {
        s.extraPhones = s.extraPhones.filter(p => p !== cleaned);
    }
    saveSettings(s);
    
    try {
        await startBot(cleaned);
    } catch (err) {
        console.error(`فشل تشغيل الرقم الأساسي ${cleaned}:`, err);
    }
    
    res.json({ success: true, welcomeNumber: cleaned });
});

// ── الحصول على قائمة الأرقام فقط ─────────────
router.get('/phones', (req, res) => {
    const s = loadSettings();
    res.json({
        welcomeNumber: s.welcomeNumber || null,
        extraPhones: s.extraPhones || []
    });
});

// ── تحديث السيرفر من رابط GitHub ─────────────
router.post('/update-server', async (req, res) => {
    const { url } = req.body;
    if (!url) {
        return res.status(400).json({ success: false, message: 'الرابط مطلوب' });
    }

    res.json({ success: true, message: 'بدء التحديث...' });

    setTimeout(async () => {
        try {
            // نسخ احتياطي للملفات الحساسة
            const backupDir = path.join(__dirname, '..', 'backup_' + Date.now());
            fs.mkdirSync(backupDir);
            const filesToBackup = ['settings.json', 'commands.json', 'warnings_data.json', 'marriage_data.json'];
            filesToBackup.forEach(f => {
                const src = path.join(__dirname, '..', f);
                if (fs.existsSync(src)) fs.copyFileSync(src, path.join(backupDir, f));
            });
            const authSrc = path.join(__dirname, '..', 'auth_sessions');
            if (fs.existsSync(authSrc)) {
                fs.cpSync(authSrc, path.join(backupDir, 'auth_sessions'), { recursive: true });
            }
            const uploadsSrc = path.join(__dirname, '..', 'uploads');
            if (fs.existsSync(uploadsSrc)) {
                fs.cpSync(uploadsSrc, path.join(backupDir, 'uploads'), { recursive: true });
            }
            logToApp('📦 تم إنشاء نسخة احتياطية في: ' + backupDir);

            const tempZip = path.join(__dirname, '..', 'update.zip');
            const extractPath = path.join(__dirname, '..');

            logToApp('📥 جاري تحميل التحديث من: ' + url);

            const response = await axios.get(url, { responseType: 'arraybuffer' });
            fs.writeFileSync(tempZip, response.data);

            logToApp('📦 جاري فك الضغط...');

            const zip = new AdmZip(tempZip);
            const entries = zip.getEntries();

            let rootPrefix = '';
            const rootEntries = entries.filter(e => !e.entryName.includes('/') || e.entryName.split('/')[0]);
            if (rootEntries.length === 1 && rootEntries[0].isDirectory) {
                rootPrefix = rootEntries[0].entryName;
                logToApp('📁 تم اكتشاف مجلد جذري: ' + rootPrefix);
            }

            entries.forEach(entry => {
                let relativePath = entry.entryName;
                if (rootPrefix && relativePath.startsWith(rootPrefix)) {
                    relativePath = relativePath.substring(rootPrefix.length);
                    if (relativePath.startsWith('/')) relativePath = relativePath.substring(1);
                }

                // تجاهل الملفات والمجلدات الحساسة
                if (relativePath.startsWith('auth_sessions/') ||
                    relativePath === 'settings.json' ||
                    relativePath === 'commands.json' ||
                    relativePath === 'warnings_data.json' ||
                    relativePath === 'marriage_data.json' ||
                    relativePath.startsWith('temp_media/') ||
                    relativePath.startsWith('uploads/') ||
                    relativePath.startsWith('backup_') ||
                    relativePath.startsWith('vid') ||
                    relativePath === '' ||
                    relativePath.endsWith('/')) {
                    return;
                }

                const targetPath = path.join(extractPath, relativePath);
                const targetDir = path.dirname(targetPath);
                if (!fs.existsSync(targetDir)) {
                    fs.mkdirSync(targetDir, { recursive: true });
                }

                zip.extractEntryTo(entry, targetDir, false, true);
                
                const extractedName = path.join(targetDir, path.basename(entry.entryName));
                if (extractedName !== targetPath && fs.existsSync(extractedName)) {
                    fs.renameSync(extractedName, targetPath);
                }
                logToApp('📄 تم تحديث: ' + relativePath);
            });

            fs.unlinkSync(tempZip);

            logToApp('✅ تم التحديث بنجاح، جاري إعادة تشغيل السيرفر...');
            setTimeout(() => process.exit(0), 2000);
        } catch (err) {
            logToApp('❌ فشل التحديث: ' + err.message);
        }
    }, 1000);
});

module.exports = router;