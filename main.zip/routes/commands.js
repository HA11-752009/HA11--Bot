// routes/commands.js — إدارة الأوامر
const express = require('express');
const router  = express.Router();
const fs      = require('fs');
const path    = require('path');
const { loadCommands, saveCommands } = require('../persistence');
const { PLUGINS_DIR } = require('../config');

// ── جلب أوامر plugins ─────────────────────
function getPluginCommands() {
    const result = [];
    if (!fs.existsSync(PLUGINS_DIR)) return result;
    const files = fs.readdirSync(PLUGINS_DIR).filter(f => f.endsWith('.js'));
    for (const file of files) {
        try {
            delete require.cache[require.resolve(path.join(PLUGINS_DIR, file))];
            const plugin = require(path.join(PLUGINS_DIR, file));
            const cmds   = Array.isArray(plugin) ? plugin : [plugin];
            for (const cmd of cmds) {
                if (!cmd.trigger || typeof cmd.handler !== 'function') continue;
                result.push({
                    id:            `plugin_${cmd.trigger}`,
                    trigger:       cmd.trigger,
                    description:   cmd.description || '',
                    actionType:    'plugin',
                    pluginTrigger: cmd.trigger,
                    isEnabled:     true,
                    usageCount:    0,
                    fromPlugin:    true,
                    pluginFile:    file,
                    groupOnly:     cmd.groupOnly || false,
                    adminOnly:     cmd.adminOnly || false,
                    createdAt:     new Date().toISOString()
                });
            }
        } catch {}
    }
    return result;
}

// ── GET /api/commands ─────────────────────
router.get('/', (req, res) => {
    const dbCmds     = loadCommands();
    const pluginCmds = getPluginCommands();

    // دمج: DB يكسب على Plugin بنفس الـ trigger
    const merged = [...pluginCmds];
    for (const dbCmd of dbCmds) {
        const idx = merged.findIndex(c => c.trigger === dbCmd.trigger && c.fromPlugin);
        if (idx !== -1) {
            merged[idx] = { ...merged[idx], ...dbCmd, fromPlugin: true };
        } else {
            merged.push(dbCmd);
        }
    }
    res.json({ commands: merged, total: merged.length });
});

// ── POST /api/commands — إضافة أمر جديد ───
router.post('/', (req, res) => {
    const commands = loadCommands();
    const newCmd   = {
        id:            Date.now().toString(),
        trigger:       req.body.trigger?.toLowerCase().trim(),
        description:   req.body.description || '',
        actionType:    req.body.actionType || 'text',
        actionData:    req.body.actionData || req.body.response || '',
        response:      req.body.response || req.body.actionData || '',
        mediaUrl:      req.body.mediaUrl || null,
        caption:       req.body.caption || null,
        mediaType:     req.body.mediaType || null,
        pluginTrigger: req.body.pluginTrigger || null,
        isEnabled:     true,
        usageCount:    0,
        fromPlugin:    false,
        createdAt:     new Date().toISOString(),
        // حقول جديدة
        jokes:         req.body.jokes || null,
        buttonLabel:   req.body.buttonLabel || null,
        buttonAction:  req.body.buttonAction || null,
        buttonValue:   req.body.buttonValue || null,
        goodbyeMessage: req.body.goodbyeMessage || null,
        showProfilePic: req.body.showProfilePic || false
    };
    if (!newCmd.trigger) return res.status(400).json({ error: 'trigger مطلوب' });
    if (commands.find(c => c.trigger === newCmd.trigger))
        return res.status(409).json({ error: 'الأمر موجود بالفعل' });
    commands.push(newCmd);
    saveCommands(commands);
    res.json({ success: true, command: newCmd });
});

// ── PUT /api/commands/:id — تعديل أمر ──────
router.put('/:id', (req, res) => {
    const commands = loadCommands();
    const idx      = commands.findIndex(c => c.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'أمر غير موجود' });
    commands[idx] = { ...commands[idx], ...req.body, id: req.params.id };
    saveCommands(commands);
    res.json({ success: true, command: commands[idx] });
});

// ── DELETE /api/commands/:id — حذف أمر ─────
router.delete('/:id', (req, res) => {
    let commands = loadCommands();
    const before = commands.length;
    commands = commands.filter(c => c.id !== req.params.id);
    if (commands.length === before) return res.status(404).json({ error: 'أمر غير موجود' });
    saveCommands(commands);
    res.json({ success: true });
});

// ── PATCH /api/commands/:id/toggle ─────────
router.patch('/:id/toggle', (req, res) => {
    const commands = loadCommands();
    const cmd      = commands.find(c => c.id === req.params.id);
    if (!cmd) return res.status(404).json({ error: 'أمر غير موجود' });
    cmd.isEnabled = !cmd.isEnabled;
    saveCommands(commands);
    res.json({ success: true, isEnabled: cmd.isEnabled });
});

module.exports = router;