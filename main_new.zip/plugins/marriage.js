// =============================================
// plugins/marriage.js — نظام زواج متكامل 💍
// =============================================
const fs = require('fs');
const path = require('path');
const { logToApp } = require('../ws');

const DATA_FILE = path.join(__dirname, '..', 'marriage_data.json');

function loadData() {
    try {
        if (fs.existsSync(DATA_FILE))
            return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    } catch (e) {}
    return {};
}

function saveData(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function getPhone(jid) {
    if (!jid) return '';
    // استخراج الرقم من JID (مثل 1234567890@s.whatsapp.net)
    let phone = jid.split('@')[0];
    // إزالة أي أرقام إضافية بعد ":" إن وجدت (للمجموعات أحياناً)
    phone = phone.split(':')[0];
    return phone;
}

// دالة موحدة لاستخراج الـ JID المستهدف من الرسالة (منشن أو اقتباس أو رقم)
function extractTargetJid(msg, args, senderJid) {
    // 1. من الاقتباس
    const ctxInfo = msg.message?.extendedTextMessage?.contextInfo;
    if (ctxInfo?.participant) {
        return ctxInfo.participant;
    }
    // 2. من المنشن (mentionedJid)
    if (ctxInfo?.mentionedJid && ctxInfo.mentionedJid.length > 0) {
        return ctxInfo.mentionedJid[0];
    }
    // 3. من النص (إذا كتب رقم مباشرة)
    if (args.length > 0) {
        const possibleNumber = args[0].replace(/\D/g, '');
        if (possibleNumber.length >= 10) {
            return `${possibleNumber}@s.whatsapp.net`;
        }
    }
    return null;
}

// رسائل الزفاف
const WEDDING_MSGS = [
    '🎊 *مبروك يا عروسين!* 🎊\n@{groom} 🤵 و @{bride} 👰\nربنا يسعدكم ويبارك لكم ❤️',
    '💒 *عقد قران سعيد* 💒\nالعريس: @{groom}\nالعروس: @{bride}\nألف مبروك والله يتمملكم بخير 🌹',
    '🎉 *زفاف على أصوله* 🎉\n@{groom} و @{bride} صاروا زوجين رسمياً! 🥂',
    '💍 *الزواج الناجح* 💍\nربنا يخليكم لبعض @{groom} و @{bride} ويجمعكم في خير 💑',
    '🥳 *فرحة كبيرة* 🥳\n@{groom} ارتبط بـ @{bride}\nكل التهاني والتبريكات 🎁',
    '🌹 *قصة حب جديدة* 🌹\n@{groom} اختار @{bride} ليكون شريك حياته\nمبروك ❤️',
];

// رسائل الإهداء
const GIFT_MSGS = [
    '🎁 *هدية رومانسية* 🎁\n@{sender} أهدى @{receiver} وردة حمراء 🌹',
    '💎 *هدية قيمة* 💎\n@{sender} أهدى @{receiver} خاتم من الألماس 💍',
    '🍫 *هدية حلوة* 🍫\n@{sender} أهدى @{receiver} علبة شوكولاتة 🍬',
    '📖 *هدية عاطفية* 📖\n@{sender} كتب قصيدة حب وأهداها لـ @{receiver} ✍️',
    '🎀 *هدية بسيطة* 🎀\n@{sender} أهدى @{receiver} دبدوب كبير 🧸',
];

const proposals = new Map();

async function sendWeddingMessage(sock, groupId, groomJid, brideJid) {
    const groomPhone = getPhone(groomJid);
    const bridePhone = getPhone(brideJid);
    const template = WEDDING_MSGS[Math.floor(Math.random() * WEDDING_MSGS.length)];
    const text = template.replace(/{groom}/g, groomPhone).replace(/{bride}/g, bridePhone);
    await sock.sendMessage(groupId, { text, mentions: [groomJid, brideJid] });
}

module.exports = [
    // 1. جواز (يدعم المنشن والاقتباس والرقم)
    {
        trigger: 'جواز',
        description: 'اقتراح زواج (منشن أو اقتباس أو رقم) 💍',
        groupOnly: true,
        handler: async ({ sock, from, msg, senderJid, args }) => {
            const data = loadData();
            if (!data[from]) data[from] = {};

            const targetJid = extractTargetJid(msg, args, senderJid);
            if (!targetJid) {
                await sock.sendMessage(from, { text: '💍 اذكر الشخص بعد الأمر، مثلاً: `!جواز @أحمد` أو رد على رسالته.' });
                return;
            }

            const senderPhone = getPhone(senderJid);
            const targetPhone = getPhone(targetJid);

            if (senderJid === targetJid) {
                await sock.sendMessage(from, { text: '❌ مينفعش تتجوز نفسك! 😅' });
                return;
            }

            if (data[from][senderPhone]) {
                await sock.sendMessage(from, {
                    text: `❌ انت متجوز بالفعل من @${data[from][senderPhone]}!\nاطلق أولاً بـ !طلاق`,
                    mentions: [senderJid]
                });
                return;
            }
            if (data[from][targetPhone]) {
                await sock.sendMessage(from, {
                    text: `❌ @${targetPhone} متزوج بالفعل!`,
                    mentions: [targetJid]
                });
                return;
            }

            proposals.set(`${from}:${senderPhone}`, targetJid);
            await sock.sendMessage(from, {
                text: `💍 *اقتراح زواج!*\n@${senderPhone} بيقترح الجواز على @${targetPhone}\n\n@${targetPhone} رد بـ: ✅ !قبلت  أو  ❌ !رفضت`,
                mentions: [senderJid, targetJid]
            });
        }
    },
    // 2. قبول
    {
        trigger: 'قبلت',
        description: 'قبول طلب الزواج ✅',
        groupOnly: true,
        handler: async ({ sock, from, senderJid }) => {
            const data = loadData();
            if (!data[from]) data[from] = {};
            const targetPhone = getPhone(senderJid);
            let proposerJid = null;
            for (const [key, target] of proposals) {
                if (key.startsWith(`${from}:`) && target === senderJid) {
                    proposerJid = key.split(':').slice(1).join(':');
                    proposals.delete(key);
                    break;
                }
            }
            if (!proposerJid) {
                await sock.sendMessage(from, { text: '❌ مفيش اقتراح زواج موجه ليك!' });
                return;
            }
            const proposerPhone = proposerJid;
            data[from][proposerPhone] = targetPhone;
            data[from][targetPhone] = proposerPhone;
            saveData(data);
            await sendWeddingMessage(sock, from, `${proposerPhone}@s.whatsapp.net`, senderJid);
        }
    },
    // 3. رفض
    {
        trigger: 'رفضت',
        description: 'رفض طلب الزواج ❌',
        groupOnly: true,
        handler: async ({ sock, from, senderJid }) => {
            for (const [key, target] of proposals) {
                if (key.startsWith(`${from}:`) && target === senderJid) {
                    const proposerPhone = key.split(':').slice(1).join(':');
                    proposals.delete(key);
                    await sock.sendMessage(from, {
                        text: `💔 @${getPhone(senderJid)} رفض الاقتراح!\n@${proposerPhone} متزعلش! 😅`,
                        mentions: [senderJid, `${proposerPhone}@s.whatsapp.net`]
                    });
                    return;
                }
            }
            await sock.sendMessage(from, { text: '❌ مفيش اقتراح موجه ليك!' });
        }
    },
    // 4. طلاق
    {
        trigger: 'طلاق',
        description: 'الطلاق من الزوج/ة 💔',
        groupOnly: true,
        handler: async ({ sock, from, senderJid }) => {
            const data = loadData();
            if (!data[from]) data[from] = {};
            const senderPhone = getPhone(senderJid);
            const partner = data[from][senderPhone];
            if (!partner) {
                await sock.sendMessage(from, { text: '❌ انت مش متجوز أصلاً! 😅' });
                return;
            }
            delete data[from][senderPhone];
            delete data[from][partner];
            saveData(data);
            await sock.sendMessage(from, {
                text: `💔 *تم الطلاق!*\n@${senderPhone} طلّق @${partner}\nالدنيا فانية 😢`,
                mentions: [senderJid, `${partner}@s.whatsapp.net`]
            });
        }
    },
    // 5. زوجتي
    {
        trigger: 'زوجتي',
        description: 'عرض اسم زوجك/زوجتك 💑',
        groupOnly: true,
        handler: async ({ sock, from, senderJid }) => {
            const data = loadData();
            const partner = data[from]?.[getPhone(senderJid)];
            if (!partner) {
                await sock.sendMessage(from, { text: '💔 انت أعزب/عزباء!\nاستخدم !جواز أو !زوجني للارتباط' });
            } else {
                await sock.sendMessage(from, {
                    text: `💑 أنت متزوج من @${partner} ❤️`,
                    mentions: [`${partner}@s.whatsapp.net`]
                });
            }
        }
    },
    // 6. زواج عشوائي (بين اثنين)
    {
        trigger: 'زواج',
        description: 'زواج عشوائي بين عضوين في المجموعة 🎲',
        groupOnly: true,
        handler: async ({ sock, from }) => {
            const data = loadData();
            if (!data[from]) data[from] = {};
            const meta = await sock.groupMetadata(from);
            const members = meta.participants.map(p => p.id);
            if (members.length < 2) {
                await sock.sendMessage(from, { text: '👥 المجموعة تحتاج عضوين على الأقل للزواج!' });
                return;
            }
            let groom, bride;
            let attempts = 0;
            do {
                const shuffled = [...members].sort(() => Math.random() - 0.5);
                groom = shuffled[0];
                bride = shuffled[1];
                attempts++;
                if (attempts > 20) break;
            } while (groom === bride || data[from][getPhone(groom)] || data[from][getPhone(bride)]);
            if (groom === bride || data[from][getPhone(groom)] || data[from][getPhone(bride)]) {
                await sock.sendMessage(from, { text: '⚠️ لم نجد شخصين غير مرتبطين، حاول مرة أخرى!' });
                return;
            }
            const groomPhone = getPhone(groom);
            const bridePhone = getPhone(bride);
            data[from][groomPhone] = bridePhone;
            data[from][bridePhone] = groomPhone;
            saveData(data);
            await sendWeddingMessage(sock, from, groom, bride);
        }
    },
    // 7. ازواج (قائمة المتزوجين)
    {
        trigger: 'ازواج',
        description: 'عرض قائمة الأزواج في المجموعة 📜',
        groupOnly: true,
        handler: async ({ sock, from }) => {
            const data = loadData();
            const marriages = data[from] || {};
            const couples = [];
            const paired = new Set();
            for (const [person, partner] of Object.entries(marriages)) {
                if (paired.has(person) || paired.has(partner)) continue;
                if (partner && marriages[partner] === person) {
                    couples.push(`❤️ @${person} متزوج من @${partner}`);
                    paired.add(person);
                    paired.add(partner);
                }
            }
            if (couples.length === 0) {
                await sock.sendMessage(from, { text: '📭 لا يوجد أزواج في هذه المجموعة بعد.' });
                return;
            }
            const text = `👫 *قائمة الأزواج في المجموعة:*\n\n${couples.join('\n')}`;
            const mentions = couples.flatMap(c => {
                const matches = c.match(/@\d+/g);
                return matches ? matches.map(m => `${m.slice(1)}@s.whatsapp.net`) : [];
            });
            await sock.sendMessage(from, { text, mentions });
        }
    },
    // 8. اهداء
    {
        trigger: 'اهداء',
        description: 'أرسل هدية لزوجك/زوجتك 🎁',
        groupOnly: true,
        handler: async ({ sock, from, senderJid }) => {
            const data = loadData();
            const senderPhone = getPhone(senderJid);
            const partner = data[from]?.[senderPhone];
            if (!partner) {
                await sock.sendMessage(from, { text: '❌ ليس لديك زوج/زوجة لتُهديه!' });
                return;
            }
            const giftMsg = GIFT_MSGS[Math.floor(Math.random() * GIFT_MSGS.length)];
            const finalMsg = giftMsg.replace(/{sender}/g, senderPhone).replace(/{receiver}/g, partner);
            await sock.sendMessage(from, {
                text: finalMsg,
                mentions: [senderJid, `${partner}@s.whatsapp.net`]
            });
        }
    },
    // 9. زوجني (يتزوجك أنت بشخص عشوائي)
    {
        trigger: 'زوجني',
        description: 'يتزوجك بشخص عشوائي في المجموعة 💘',
        groupOnly: true,
        handler: async ({ sock, from, senderJid }) => {
            const data = loadData();
            if (!data[from]) data[from] = {};
            const senderPhone = getPhone(senderJid);
            if (data[from][senderPhone]) {
                await sock.sendMessage(from, {
                    text: `❌ انت متزوج بالفعل من @${data[from][senderPhone]}!\nاطلق أولاً بـ !طلاق`,
                    mentions: [senderJid]
                });
                return;
            }
            const meta = await sock.groupMetadata(from);
            const members = meta.participants.map(p => p.id).filter(id => id !== senderJid);
            if (members.length === 0) {
                await sock.sendMessage(from, { text: '👥 لا يوجد أعضاء آخرين في المجموعة للزواج!' });
                return;
            }
            const available = members.filter(id => !data[from][getPhone(id)]);
            if (available.length === 0) {
                await sock.sendMessage(from, { text: '⚠️ جميع الأعضاء متزوجون بالفعل! لا يوجد عازبين.' });
                return;
            }
            const randomIndex = Math.floor(Math.random() * available.length);
            const partnerJid = available[randomIndex];
            const partnerPhone = getPhone(partnerJid);
            data[from][senderPhone] = partnerPhone;
            data[from][partnerPhone] = senderPhone;
            saveData(data);
            await sendWeddingMessage(sock, from, senderJid, partnerJid);
        }
    }
];

logToApp('💍 Marriage plugin loaded: جواز (منشن/اقتباس/رقم), قبلت, رفضت, طلاق, زوجتي, زواج, ازواج, اهداء, زوجني');